<?php
/**
 * 平衡計分卡管理系統 - 策略地圖
 * 顯示策略目標間的因果關係圖
 */
require_once 'config.php';

$conn = getDbConnection();

$message = '';
$editData = null;

// 處理新增關聯
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_relation') {
    $from_id = (int)$_POST['from_objective_id'];
    $to_id = (int)$_POST['to_objective_id'];
    $type = $conn->real_escape_string($_POST['relation_type']);
    $desc = $conn->real_escape_string($_POST['description']);
    
    $sql = "INSERT INTO strategy_map_relations (from_objective_id, to_objective_id, relation_type, description) 
            VALUES ($from_id, $to_id, '$type', '$desc')";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 關聯新增成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 新增失敗：" . $conn->error . "</div>";
    }
}

// 處理編輯關聯
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_relation') {
    $id = (int)$_POST['id'];
    $from_id = (int)$_POST['from_objective_id'];
    $to_id = (int)$_POST['to_objective_id'];
    $type = $conn->real_escape_string($_POST['relation_type']);
    $desc = $conn->real_escape_string($_POST['description']);
    
    $sql = "UPDATE strategy_map_relations 
            SET from_objective_id=$from_id, to_objective_id=$to_id, 
                relation_type='$type', description='$desc'
            WHERE id=$id";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 關聯更新成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 更新失敗：" . $conn->error . "</div>";
    }
}

// 處理刪除關聯
if (isset($_GET['delete_relation'])) {
    $id = (int)$_GET['delete_relation'];
    if (safeQuery($conn, "DELETE FROM strategy_map_relations WHERE id = $id")) {
        $message = "<div class='alert alert-success'>✓ 關聯刪除成功！</div>";
    }
}

// 取得編輯資料
if (isset($_GET['edit_relation'])) {
    $editData = fetchOne($conn, "SELECT * FROM strategy_map_relations WHERE id = " . (int)$_GET['edit_relation']);
}

// 查詢所有構面
$perspectives = fetchAll($conn, "SELECT * FROM perspectives ORDER BY display_order");

// 查詢所有策略目標
$objectives = fetchAll($conn, "
    SELECT 
        so.*,
        p.name as perspective_name,
        p.color,
        COUNT(DISTINCT k.id) as kpi_count,
        ROUND(AVG(kr.achievement_rate), 2) as avg_achievement
    FROM strategic_objectives so
    JOIN perspectives p ON so.perspective_id = p.id
    LEFT JOIN kpis k ON so.id = k.objective_id
    LEFT JOIN (
        SELECT kr1.*
        FROM kpi_records kr1
        INNER JOIN (
            SELECT kpi_id, MAX(record_date) as max_date
            FROM kpi_records
            GROUP BY kpi_id
        ) kr2 ON kr1.kpi_id = kr2.kpi_id AND kr1.record_date = kr2.max_date
    ) kr ON k.id = kr.kpi_id
    GROUP BY so.id
    ORDER BY p.display_order, so.display_order
");

// 查詢所有關聯關係
$relations = fetchAll($conn, "
    SELECT 
        r.*,
        so1.name as from_name,
        so2.name as to_name,
        p1.name as from_perspective,
        p2.name as to_perspective
    FROM strategy_map_relations r
    JOIN strategic_objectives so1 ON r.from_objective_id = so1.id
    JOIN strategic_objectives so2 ON r.to_objective_id = so2.id
    JOIN perspectives p1 ON so1.perspective_id = p1.id
    JOIN perspectives p2 ON so2.perspective_id = p2.id
    ORDER BY r.id
");

renderHeader('策略地圖');
?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 30px 0;">
        <h1 style="font-size: 32px; color: #333;">🗺️ 策略地圖</h1>
        <button onclick="openAddModal()" class="btn">
            ➕ 新增目標關聯
        </button>
    </div>
    
    <?php echo $message; ?>
    
    <div class="alert alert-info">
        <strong>💡 策略地圖說明：</strong> 策略地圖展示從學習與成長構面到財務構面的因果關係鏈，幫助理解各策略目標之間的邏輯關聯。顏色深淺代表目標達成率。
    </div>
    
    <!-- SVG策略地圖 -->
    <div class="card" style="overflow-x: auto;">
        <svg id="strategyMap" width="100%" height="800" style="border: 1px solid #e0e0e0; background: #fafafa;">
            <!-- 由JavaScript動態生成 -->
        </svg>
    </div>
    
    <!-- 關聯關係列表 -->
    <div class="card">
        <h2>🔗 目標關聯關係列表</h2>
        <?php if (count($relations) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>來源構面</th>
                    <th>來源目標</th>
                    <th>關聯類型</th>
                    <th>目的構面</th>
                    <th>目的目標</th>
                    <th>說明</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($relations as $rel): ?>
                <tr>
                    <td><?php echo htmlspecialchars($rel['from_perspective']); ?></td>
                    <td><strong><?php echo htmlspecialchars($rel['from_name']); ?></strong></td>
                    <td>
                        <span class="badge badge-info"><?php echo htmlspecialchars($rel['relation_type']); ?></span>
                    </td>
                    <td><?php echo htmlspecialchars($rel['to_perspective']); ?></td>
                    <td><strong><?php echo htmlspecialchars($rel['to_name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($rel['description']); ?></td>
                    <td style="white-space: nowrap;">
                        <button onclick="editRelation(<?php echo htmlspecialchars(json_encode($rel)); ?>)" 
                                class="btn btn-small btn-warning">
                            ✏️ 編輯
                        </button>
                        <a href="?delete_relation=<?php echo $rel['id']; ?>" 
                           class="btn btn-small btn-danger"
                           onclick="return confirm('確定要刪除此關聯嗎？')">
                            🗑️ 刪除
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="text-align: center; color: #999; padding: 20px;">目前沒有設定目標關聯</p>
        <?php endif; ?>
    </div>
    
    <!-- 圖例說明 -->
    <div class="card">
        <h2>📖 圖例說明</h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
            <div style="padding: 10px; background: #f8f9fa; border-radius: 6px;">
                <strong>🟢 綠色（達成率 ≥ 100%）</strong><br>
                <span style="color: #666;">目標已達成</span>
            </div>
            <div style="padding: 10px; background: #f8f9fa; border-radius: 6px;">
                <strong>🟡 橘色（80% ≤ 達成率 < 100%）</strong><br>
                <span style="color: #666;">接近目標</span>
            </div>
            <div style="padding: 10px; background: #f8f9fa; border-radius: 6px;">
                <strong>🔴 紅色（達成率 < 80%）</strong><br>
                <span style="color: #666;">需要改善</span>
            </div>
            <div style="padding: 10px; background: #f8f9fa; border-radius: 6px;">
                <strong>⚪ 灰色</strong><br>
                <span style="color: #666;">尚無績效資料</span>
            </div>
        </div>
    </div>
</div>

<!-- 新增/編輯關聯視窗 -->
<div id="relationModal" style="display: <?php echo $editData ? 'block' : 'none'; ?>; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
    <div style="position: relative; max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
        <h2 id="formTitle"><?php echo $editData ? '編輯目標關聯' : '新增目標關聯'; ?></h2>
        
        <form method="POST" id="relationForm">
            <input type="hidden" name="action" id="formAction" value="<?php echo $editData ? 'edit_relation' : 'add_relation'; ?>">
            <input type="hidden" name="id" id="formId" value="<?php echo $editData ? $editData['id'] : ''; ?>">
            
            <div class="form-group">
                <label>來源目標（原因）*</label>
                <select name="from_objective_id" id="formFrom" required>
                    <option value="">請選擇來源目標</option>
                    <?php foreach ($objectives as $obj): ?>
                        <option value="<?php echo $obj['id']; ?>"
                                <?php echo ($editData && $editData['from_objective_id'] == $obj['id']) ? 'selected' : ''; ?>>
                            [<?php echo htmlspecialchars($obj['perspective_name']); ?>] 
                            <?php echo htmlspecialchars($obj['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>目的目標（結果）*</label>
                <select name="to_objective_id" id="formTo" required>
                    <option value="">請選擇目的目標</option>
                    <?php foreach ($objectives as $obj): ?>
                        <option value="<?php echo $obj['id']; ?>"
                                <?php echo ($editData && $editData['to_objective_id'] == $obj['id']) ? 'selected' : ''; ?>>
                            [<?php echo htmlspecialchars($obj['perspective_name']); ?>] 
                            <?php echo htmlspecialchars($obj['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>關聯類型 *</label>
                <select name="relation_type" id="formType" required>
                    <option value="因果" <?php echo ($editData && $editData['relation_type'] == '因果') ? 'selected' : ''; ?>>因果關係</option>
                    <option value="支援" <?php echo ($editData && $editData['relation_type'] == '支援') ? 'selected' : ''; ?>>支援關係</option>
                    <option value="影響" <?php echo ($editData && $editData['relation_type'] == '影響') ? 'selected' : ''; ?>>影響關係</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>關聯說明</label>
                <textarea name="description" id="formDescription" rows="3" 
                          placeholder="描述兩個目標之間的關聯性..."><?php echo $editData ? htmlspecialchars($editData['description']) : ''; ?></textarea>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-success">
                    ✓ <?php echo $editData ? '更新' : '儲存'; ?>
                </button>
                <button type="button" class="btn" onclick="closeModal()">✗ 取消</button>
            </div>
        </form>
    </div>
</div>

<script>
// 準備資料
const perspectives = <?php echo json_encode($perspectives); ?>;
const objectives = <?php echo json_encode($objectives); ?>;
const relations = <?php echo json_encode($relations); ?>;

// 開啟新增視窗
function openAddModal() {
    document.getElementById('relationModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '新增目標關聯';
    document.getElementById('formAction').value = 'add_relation';
    document.getElementById('formId').value = '';
    document.getElementById('relationForm').reset();
}

// 編輯關聯
function editRelation(data) {
    document.getElementById('relationModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '編輯目標關聯';
    document.getElementById('formAction').value = 'edit_relation';
    document.getElementById('formId').value = data.id;
    document.getElementById('formFrom').value = data.from_objective_id;
    document.getElementById('formTo').value = data.to_objective_id;
    document.getElementById('formType').value = data.relation_type;
    document.getElementById('formDescription').value = data.description || '';
}

// 關閉視窗
function closeModal() {
    document.getElementById('relationModal').style.display = 'none';
}

// 點擊背景關閉
document.getElementById('relationModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

<?php if ($editData): ?>
// 自動開啟編輯視窗
document.getElementById('relationModal').style.display = 'block';
<?php endif; ?>

// 繪製策略地圖
function drawStrategyMap() {
    const svg = document.getElementById('strategyMap');
    const width = svg.clientWidth;
    const height = 800;
    const layerHeight = height / perspectives.length;
    
    // 清空SVG
    svg.innerHTML = '';
    
    // 按構面組織目標
    const objByPerspective = {};
    perspectives.forEach(p => {
        objByPerspective[p.id] = objectives.filter(o => o.perspective_id == p.id);
    });
    
    // 儲存目標位置（用於繪製連線）
    const positions = {};
    
    // 繪製每個構面層
    perspectives.forEach((persp, pIdx) => {
        const y = pIdx * layerHeight + 50;
        const objs = objByPerspective[persp.id] || [];
        const objWidth = 180;
        const spacing = Math.min((width - 100 - objs.length * objWidth) / (objs.length + 1), 80);
        
        // 繪製構面標籤背景
        const labelBg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        labelBg.setAttribute('x', 0);
        labelBg.setAttribute('y', y - 30);
        labelBg.setAttribute('width', width);
        labelBg.setAttribute('height', layerHeight);
        labelBg.setAttribute('fill', persp.color + '11');
        labelBg.setAttribute('stroke', persp.color);
        labelBg.setAttribute('stroke-width', 1);
        labelBg.setAttribute('stroke-dasharray', '5,5');
        svg.appendChild(labelBg);
        
        // 構面標籤
        const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('x', 20);
        label.setAttribute('y', y - 10);
        label.setAttribute('fill', persp.color);
        label.setAttribute('font-size', '18');
        label.setAttribute('font-weight', 'bold');
        label.textContent = persp.name;
        svg.appendChild(label);
        
        // 繪製目標框
        objs.forEach((obj, oIdx) => {
            const x = spacing + oIdx * (objWidth + spacing);
            const boxY = y + 20;
            
            // 記錄位置
            positions[obj.id] = { x: x + objWidth / 2, y: boxY + 40 };
            
            // 決定顏色
            let fillColor = '#e0e0e0';
            if (obj.avg_achievement !== null) {
                if (obj.avg_achievement >= 100) fillColor = '#2ecc71';
                else if (obj.avg_achievement >= 80) fillColor = '#f39c12';
                else fillColor = '#e74c3c';
            }
            
            // 目標框
            const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            rect.setAttribute('x', x);
            rect.setAttribute('y', boxY);
            rect.setAttribute('width', objWidth);
            rect.setAttribute('height', 80);
            rect.setAttribute('fill', fillColor);
            rect.setAttribute('stroke', '#333');
            rect.setAttribute('stroke-width', 2);
            rect.setAttribute('rx', 8);
            rect.setAttribute('opacity', 0.9);
            svg.appendChild(rect);
            
            // 目標名稱（分行顯示）
            const words = obj.name.split('');
            let line = '';
            let lines = [];
            words.forEach(char => {
                if (line.length >= 10) {
                    lines.push(line);
                    line = char;
                } else {
                    line += char;
                }
            });
            if (line) lines.push(line);
            
            lines.slice(0, 2).forEach((txt, idx) => {
                const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                text.setAttribute('x', x + objWidth / 2);
                text.setAttribute('y', boxY + 25 + idx * 16);
                text.setAttribute('text-anchor', 'middle');
                text.setAttribute('fill', 'white');
                text.setAttribute('font-size', '13');
                text.setAttribute('font-weight', '600');
                text.textContent = txt + (idx === 1 && lines.length > 2 ? '...' : '');
                svg.appendChild(text);
            });
            
            // 達成率
            if (obj.avg_achievement !== null) {
                const achText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                achText.setAttribute('x', x + objWidth / 2);
                achText.setAttribute('y', boxY + 65);
                achText.setAttribute('text-anchor', 'middle');
                achText.setAttribute('fill', 'white');
                achText.setAttribute('font-size', '14');
                achText.setAttribute('font-weight', 'bold');
                achText.textContent = obj.avg_achievement.toFixed(1) + '%';
                svg.appendChild(achText);
            }
        });
    });
    
    // 繪製關聯線
    relations.forEach(rel => {
        const from = positions[rel.from_objective_id];
        const to = positions[rel.to_objective_id];
        
        if (from && to) {
            // 曲線路徑
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const midY = (from.y + to.y) / 2;
            const d = `M ${from.x} ${from.y} Q ${from.x} ${midY}, ${(from.x + to.x) / 2} ${midY} T ${to.x} ${to.y}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', '#667eea');
            path.setAttribute('stroke-width', 2);
            path.setAttribute('fill', 'none');
            path.setAttribute('opacity', 0.6);
            path.setAttribute('marker-end', 'url(#arrowhead)');
            svg.insertBefore(path, svg.firstChild);
        }
    });
    
    // 定義箭頭標記
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
    marker.setAttribute('id', 'arrowhead');
    marker.setAttribute('markerWidth', 10);
    marker.setAttribute('markerHeight', 10);
    marker.setAttribute('refX', 9);
    marker.setAttribute('refY', 3);
    marker.setAttribute('orient', 'auto');
    const polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
    polygon.setAttribute('points', '0 0, 10 3, 0 6');
    polygon.setAttribute('fill', '#667eea');
    marker.appendChild(polygon);
    defs.appendChild(marker);
    svg.insertBefore(defs, svg.firstChild);
}

// 頁面載入時繪製
window.addEventListener('load', drawStrategyMap);
window.addEventListener('resize', drawStrategyMap);
</script>

<?php
$conn->close();
renderFooter();
?>