<?php
/**
 * 平衡計分卡管理系統 - 構面管理
 * 管理四大構面的新增、編輯、刪除
 */
require_once 'config.php';

$conn = getDbConnection();

$message = '';
$editData = null;

// 處理新增
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $order = (int)$_POST['display_order'];
    $color = $conn->real_escape_string($_POST['color']);
    
    $sql = "INSERT INTO perspectives (name, description, display_order, color) 
            VALUES ('$name', '$desc', $order, '$color')";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 構面新增成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 新增失敗：" . $conn->error . "</div>";
    }
}

// 處理編輯
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)$_POST['id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $order = (int)$_POST['display_order'];
    $color = $conn->real_escape_string($_POST['color']);
    
    $sql = "UPDATE perspectives 
            SET name='$name', description='$desc', display_order=$order, color='$color'
            WHERE id=$id";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 構面更新成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 更新失敗：" . $conn->error . "</div>";
    }
}

// 處理刪除
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // 檢查是否有關聯的策略目標
    $check = fetchOne($conn, "SELECT COUNT(*) as count FROM strategic_objectives WHERE perspective_id = $id");
    
    if ($check['count'] > 0) {
        $message = "<div class='alert alert-error'>✗ 無法刪除：此構面下還有 {$check['count']} 個策略目標，請先刪除相關目標。</div>";
    } else {
        if (safeQuery($conn, "DELETE FROM perspectives WHERE id = $id")) {
            $message = "<div class='alert alert-success'>✓ 構面刪除成功！</div>";
        }
    }
}

// 取得編輯資料
if (isset($_GET['edit'])) {
    $editData = fetchOne($conn, "SELECT * FROM perspectives WHERE id = " . (int)$_GET['edit']);
}

// 查詢所有構面
$perspectives = fetchAll($conn, "
    SELECT 
        p.*,
        COUNT(DISTINCT so.id) as objective_count,
        COUNT(DISTINCT k.id) as kpi_count
    FROM perspectives p
    LEFT JOIN strategic_objectives so ON p.id = so.perspective_id
    LEFT JOIN kpis k ON so.id = k.objective_id
    GROUP BY p.id
    ORDER BY p.display_order
");

renderHeader('構面管理');
?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 30px 0;">
        <h1 style="font-size: 32px; color: #333;">🎯 構面管理</h1>
        <button onclick="document.getElementById('formModal').style.display='block'; resetForm();" class="btn">
            ➕ 新增構面
        </button>
    </div>
    
    <?php echo $message; ?>
    
    <div class="alert alert-info">
        <strong>💡 構面說明：</strong> 平衡計分卡包含四大構面，從不同角度衡量組織績效。預設包含：財務構面、顧客構面、內部流程構面、學習與成長構面。您可以根據組織需求調整。
    </div>
    
    <!-- 構面列表 -->
    <div class="grid">
        <?php foreach ($perspectives as $persp): ?>
        <div class="card" style="border-left: 5px solid <?php echo $persp['color']; ?>;">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                <h3 style="color: <?php echo $persp['color']; ?>; margin: 0;">
                    <?php echo htmlspecialchars($persp['name']); ?>
                </h3>
                <span class="badge badge-info" style="font-size: 14px;">
                    順序: <?php echo $persp['display_order']; ?>
                </span>
            </div>
            
            <p style="color: #666; margin: 15px 0; line-height: 1.6;">
                <?php echo htmlspecialchars($persp['description']); ?>
            </p>
            
            <div style="display: flex; gap: 20px; margin: 15px 0; padding-top: 15px; border-top: 1px solid #e0e0e0;">
                <div>
                    <span style="color: #999; font-size: 13px;">策略目標</span>
                    <div style="font-size: 24px; font-weight: 600; color: #667eea;">
                        <?php echo $persp['objective_count']; ?>
                    </div>
                </div>
                <div>
                    <span style="color: #999; font-size: 13px;">KPI數量</span>
                    <div style="font-size: 24px; font-weight: 600; color: #667eea;">
                        <?php echo $persp['kpi_count']; ?>
                    </div>
                </div>
                <div>
                    <span style="color: #999; font-size: 13px;">顏色標記</span>
                    <div style="font-size: 24px;">
                        <span style="display: inline-block; width: 30px; height: 30px; background: <?php echo $persp['color']; ?>; border-radius: 50%; vertical-align: middle;"></span>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 15px;">
                <button onclick="editPerspective(<?php echo htmlspecialchars(json_encode($persp)); ?>)" 
                        class="btn btn-small btn-warning">
                    ✏️ 編輯
                </button>
                <a href="?delete=<?php echo $persp['id']; ?>" 
                   class="btn btn-small btn-danger"
                   onclick="return confirm('確定要刪除「<?php echo htmlspecialchars($persp['name']); ?>」嗎？\n注意：如果此構面下有策略目標，將無法刪除。')">
                    🗑️ 刪除
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <?php if (count($perspectives) === 0): ?>
    <div class="card">
        <p style="text-align: center; color: #999; padding: 40px;">
            目前沒有任何構面資料，請點選「新增構面」開始建立。
        </p>
    </div>
    <?php endif; ?>
</div>

<!-- 新增/編輯視窗 -->
<div id="formModal" style="display: <?php echo $editData ? 'block' : 'none'; ?>; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
    <div style="position: relative; max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
        <h2 id="formTitle" style="margin-bottom: 20px;">
            <?php echo $editData ? '編輯構面' : '新增構面'; ?>
        </h2>
        
        <form method="POST" id="perspectiveForm">
            <input type="hidden" name="action" id="formAction" value="<?php echo $editData ? 'edit' : 'add'; ?>">
            <input type="hidden" name="id" id="formId" value="<?php echo $editData ? $editData['id'] : ''; ?>">
            
            <div class="form-group">
                <label>構面名稱 *</label>
                <input type="text" name="name" id="formName" required 
                       value="<?php echo $editData ? htmlspecialchars($editData['name']) : ''; ?>"
                       placeholder="例如：財務構面">
            </div>
            
            <div class="form-group">
                <label>構面說明</label>
                <textarea name="description" id="formDescription" rows="4" 
                          placeholder="描述此構面的目的與衡量重點..."><?php echo $editData ? htmlspecialchars($editData['description']) : ''; ?></textarea>
            </div>
            
            <div class="form-group">
                <label>顯示順序 *</label>
                <input type="number" name="display_order" id="formOrder" required min="1"
                       value="<?php echo $editData ? $editData['display_order'] : '1'; ?>">
                <small style="color: #999;">數字越小越靠前顯示</small>
            </div>
            
            <div class="form-group">
                <label>顯示顏色 *</label>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <input type="color" name="color" id="formColor" required
                           value="<?php echo $editData ? $editData['color'] : '#3498db'; ?>"
                           style="width: 60px; height: 40px; border: 1px solid #ddd; cursor: pointer;">
                    <span id="colorPreview" style="padding: 8px 15px; border-radius: 4px; background: <?php echo $editData ? $editData['color'] : '#3498db'; ?>; color: white; font-weight: 600;">
                        預覽顏色
                    </span>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 25px;">
                <button type="submit" class="btn btn-success">
                    ✓ <?php echo $editData ? '更新' : '新增'; ?>
                </button>
                <button type="button" class="btn" onclick="closeModal()">
                    ✗ 取消
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// 顏色預覽
document.getElementById('formColor').addEventListener('input', function() {
    const color = this.value;
    document.getElementById('colorPreview').style.background = color;
});

// 重置表單（新增模式）
function resetForm() {
    document.getElementById('formTitle').textContent = '新增構面';
    document.getElementById('formAction').value = 'add';
    document.getElementById('formId').value = '';
    document.getElementById('perspectiveForm').reset();
    document.getElementById('formColor').value = '#3498db';
    document.getElementById('colorPreview').style.background = '#3498db';
}

// 編輯構面
function editPerspective(data) {
    document.getElementById('formModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '編輯構面';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('formId').value = data.id;
    document.getElementById('formName').value = data.name;
    document.getElementById('formDescription').value = data.description || '';
    document.getElementById('formOrder').value = data.display_order;
    document.getElementById('formColor').value = data.color;
    document.getElementById('colorPreview').style.background = data.color;
}

// 關閉視窗
function closeModal() {
    document.getElementById('formModal').style.display = 'none';
}

// 點擊背景關閉
document.getElementById('formModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});

<?php if ($editData): ?>
// 自動開啟編輯視窗
document.getElementById('formModal').style.display = 'block';
<?php endif; ?>
</script>

<?php
$conn->close();
renderFooter();
?>