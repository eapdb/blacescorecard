<?php
/**
 * 平衡計分卡管理系統 - 行動方案管理
 * 管理行動方案的新增、編輯、刪除
 */
require_once 'config.php';

$conn = getDbConnection();

$message = '';
$editData = null;

// 處理新增
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $objective_id = (int)$_POST['objective_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $responsible = $conn->real_escape_string($_POST['responsible_person']);
    $start_date = $conn->real_escape_string($_POST['start_date']);
    $end_date = $conn->real_escape_string($_POST['end_date']);
    $budget = (float)$_POST['budget'];
    $status = $conn->real_escape_string($_POST['status']);
    $progress = (int)$_POST['progress'];
    
    $sql = "INSERT INTO action_plans (objective_id, name, description, responsible_person, start_date, end_date, budget, status, progress) 
            VALUES ($objective_id, '$name', '$desc', '$responsible', '$start_date', '$end_date', $budget, '$status', $progress)";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 行動方案新增成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 新增失敗：" . $conn->error . "</div>";
    }
}

// 處理編輯
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)$_POST['id'];
    $objective_id = (int)$_POST['objective_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $responsible = $conn->real_escape_string($_POST['responsible_person']);
    $start_date = $conn->real_escape_string($_POST['start_date']);
    $end_date = $conn->real_escape_string($_POST['end_date']);
    $budget = (float)$_POST['budget'];
    $status = $conn->real_escape_string($_POST['status']);
    $progress = (int)$_POST['progress'];
    
    $sql = "UPDATE action_plans 
            SET objective_id=$objective_id, name='$name', description='$desc', 
                responsible_person='$responsible', start_date='$start_date', end_date='$end_date',
                budget=$budget, status='$status', progress=$progress
            WHERE id=$id";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 行動方案更新成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 更新失敗：" . $conn->error . "</div>";
    }
}

// 處理刪除
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if (safeQuery($conn, "DELETE FROM action_plans WHERE id = $id")) {
        $message = "<div class='alert alert-success'>✓ 行動方案刪除成功！</div>";
    }
}

// 取得編輯資料
if (isset($_GET['edit'])) {
    $editData = fetchOne($conn, "SELECT * FROM action_plans WHERE id = " . (int)$_GET['edit']);
}

// 查詢所有策略目標（用於下拉選單）
$objectives = fetchAll($conn, "
    SELECT so.*, p.name as perspective_name 
    FROM strategic_objectives so
    JOIN perspectives p ON so.perspective_id = p.id
    ORDER BY p.display_order, so.display_order
");

// 查詢所有行動方案
$actionPlans = fetchAll($conn, "
    SELECT 
        ap.*,
        so.name as objective_name,
        p.name as perspective_name,
        p.color,
        DATEDIFF(ap.end_date, CURDATE()) as days_remaining
    FROM action_plans ap
    JOIN strategic_objectives so ON ap.objective_id = so.id
    JOIN perspectives p ON so.perspective_id = p.id
    ORDER BY ap.status, ap.end_date
");

// 統計資料
$stats = [
    'total' => count($actionPlans),
    '規劃中' => 0,
    '執行中' => 0,
    '已完成' => 0,
    '已延期' => 0,
    '已取消' => 0
];

foreach ($actionPlans as $plan) {
    $stats[$plan['status']]++;
}

renderHeader('行動方案管理');
?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 30px 0;">
        <h1 style="font-size: 32px; color: #333;">📋 行動方案管理</h1>
        <button onclick="openAddModal()" class="btn">
            ➕ 新增行動方案
        </button>
    </div>
    
    <?php echo $message; ?>
    
    <div class="alert alert-info">
        <strong>💡 行動方案說明：</strong> 行動方案是達成策略目標的具體執行計畫。請明確設定負責人、時程、預算，並定期更新執行進度與狀態。
    </div>
    
    <!-- 統計卡片 -->
    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));">
        <div class="card" style="text-align: center; background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
            <div style="font-size: 36px; font-weight: 600;"><?php echo $stats['total']; ?></div>
            <div style="opacity: 0.9; margin-top: 5px;">總方案數</div>
        </div>
        <div class="card" style="text-align: center;">
            <div style="font-size: 36px; font-weight: 600; color: #3498db;"><?php echo $stats['規劃中']; ?></div>
            <div style="color: #666; margin-top: 5px;">規劃中</div>
        </div>
        <div class="card" style="text-align: center;">
            <div style="font-size: 36px; font-weight: 600; color: #f39c12;"><?php echo $stats['執行中']; ?></div>
            <div style="color: #666; margin-top: 5px;">執行中</div>
        </div>
        <div class="card" style="text-align: center;">
            <div style="font-size: 36px; font-weight: 600; color: #2ecc71;"><?php echo $stats['已完成']; ?></div>
            <div style="color: #666; margin-top: 5px;">已完成</div>
        </div>
        <div class="card" style="text-align: center;">
            <div style="font-size: 36px; font-weight: 600; color: #e74c3c;"><?php echo $stats['已延期']; ?></div>
            <div style="color: #666; margin-top: 5px;">已延期</div>
        </div>
    </div>
    
    <!-- 行動方案列表 -->
    <div class="card">
        <h2>📋 所有行動方案</h2>
        <?php if (count($actionPlans) > 0): ?>
        <table style="margin-top: 20px;">
            <thead>
                <tr>
                    <th>構面</th>
                    <th>策略目標</th>
                    <th>方案名稱</th>
                    <th>負責人</th>
                    <th>起訖日期</th>
                    <th>預算</th>
                    <th>進度</th>
                    <th>狀態</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($actionPlans as $plan): ?>
                <tr style="<?php echo ($plan['days_remaining'] < 0 && $plan['status'] != '已完成' && $plan['status'] != '已取消') ? 'background: #fff3cd;' : ''; ?>">
                    <td>
                        <span style="display: inline-block; width: 8px; height: 8px; background: <?php echo $plan['color']; ?>; border-radius: 50%; margin-right: 5px;"></span>
                        <?php echo htmlspecialchars($plan['perspective_name']); ?>
                    </td>
                    <td style="font-size: 13px;">
                        <?php echo htmlspecialchars($plan['objective_name']); ?>
                    </td>
                    <td>
                        <strong><?php echo htmlspecialchars($plan['name']); ?></strong>
                        <?php if (!empty($plan['description'])): ?>
                            <br><small style="color: #666;">
                                <?php echo htmlspecialchars(mb_substr($plan['description'], 0, 40)) . (mb_strlen($plan['description']) > 40 ? '...' : ''); ?>
                            </small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($plan['responsible_person']); ?></td>
                    <td style="font-size: 13px;">
                        <?php echo formatDate($plan['start_date']); ?>
                        <br>至<br>
                        <?php echo formatDate($plan['end_date']); ?>
                        <?php if ($plan['days_remaining'] > 0 && $plan['status'] == '執行中'): ?>
                            <br><small style="color: #f39c12;">剩<?php echo $plan['days_remaining']; ?>天</small>
                        <?php elseif ($plan['days_remaining'] < 0 && $plan['status'] != '已完成' && $plan['status'] != '已取消'): ?>
                            <br><small style="color: #e74c3c;">已逾期<?php echo abs($plan['days_remaining']); ?>天</small>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: right; color: #667eea; font-weight: 600;">
                        <?php echo formatNumber($plan['budget'], 0); ?>
                    </td>
                    <td style="width: 150px;">
                        <div class="progress-bar" style="height: 24px;">
                            <div class="progress-fill" style="width: <?php echo $plan['progress']; ?>%; background: <?php 
                                if ($plan['progress'] >= 100) echo '#2ecc71';
                                elseif ($plan['progress'] >= 50) echo '#f39c12';
                                else echo '#e74c3c';
                            ?>;">
                                <?php echo $plan['progress']; ?>%
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge <?php 
                            switch($plan['status']) {
                                case '規劃中': echo 'badge-info'; break;
                                case '執行中': echo 'badge-warning'; break;
                                case '已完成': echo 'badge-success'; break;
                                case '已延期': case '已取消': echo 'badge-danger'; break;
                            }
                        ?>">
                            <?php echo $plan['status']; ?>
                        </span>
                    </td>
                    <td style="white-space: nowrap;">
                        <button onclick="editPlan(<?php echo htmlspecialchars(json_encode($plan)); ?>)" 
                                class="btn btn-small btn-warning">
                            ✏️ 編輯
                        </button>
                        <a href="?delete=<?php echo $plan['id']; ?>" 
                           class="btn btn-small btn-danger"
                           onclick="return confirm('確定要刪除此行動方案嗎？')">
                            🗑️ 刪除
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="text-align: center; color: #999; padding: 40px;">
            目前沒有任何行動方案，請點選「新增行動方案」開始建立。
        </p>
        <?php endif; ?>
    </div>
</div>

<!-- 新增/編輯視窗 -->
<div id="formModal" style="display: <?php echo $editData ? 'block' : 'none'; ?>; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
    <div style="position: relative; max-width: 800px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
        <h2 id="formTitle"><?php echo $editData ? '編輯行動方案' : '新增行動方案'; ?></h2>
        
        <form method="POST" id="planForm">
            <input type="hidden" name="action" id="formAction" value="<?php echo $editData ? 'edit' : 'add'; ?>">
            <input type="hidden" name="id" id="formId" value="<?php echo $editData ? $editData['id'] : ''; ?>">
            
            <div class="form-group">
                <label>所屬策略目標 *</label>
                <select name="objective_id" id="formObjective" required>
                    <option value="">請選擇策略目標</option>
                    <?php foreach ($objectives as $obj): ?>
                        <option value="<?php echo $obj['id']; ?>"
                                <?php echo ($editData && $editData['objective_id'] == $obj['id']) ? 'selected' : ''; ?>>
                            [<?php echo htmlspecialchars($obj['perspective_name']); ?>] 
                            <?php echo htmlspecialchars($obj['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>方案名稱 *</label>
                <input type="text" name="name" id="formName" required 
                       value="<?php echo $editData ? htmlspecialchars($editData['name']) : ''; ?>"
                       placeholder="例如：年度教育訓練計畫">
            </div>
            
            <div class="form-group">
                <label>方案說明</label>
                <textarea name="description" id="formDescription" rows="4"
                          placeholder="詳細描述此行動方案的內容、執行方式與預期效益..."><?php echo $editData ? htmlspecialchars($editData['description']) : ''; ?></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>負責人 *</label>
                    <input type="text" name="responsible_person" id="formResponsible" required
                           value="<?php echo $editData ? htmlspecialchars($editData['responsible_person']) : ''; ?>"
                           placeholder="輸入負責人姓名或部門">
                </div>
                
                <div class="form-group">
                    <label>預算金額 (元)</label>
                    <input type="number" name="budget" id="formBudget" min="0" step="1"
                           value="<?php echo $editData ? $editData['budget'] : '0'; ?>">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>開始日期 *</label>
                    <input type="date" name="start_date" id="formStartDate" required
                           value="<?php echo $editData ? $editData['start_date'] : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label>結束日期 *</label>
                    <input type="date" name="end_date" id="formEndDate" required
                           value="<?php echo $editData ? $editData['end_date'] : ''; ?>">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>狀態 *</label>
                    <select name="status" id="formStatus" required>
                        <option value="規劃中" <?php echo ($editData && $editData['status'] == '規劃中') ? 'selected' : ''; ?>>規劃中</option>
                        <option value="執行中" <?php echo ($editData && $editData['status'] == '執行中') ? 'selected' : ''; ?>>執行中</option>
                        <option value="已完成" <?php echo ($editData && $editData['status'] == '已完成') ? 'selected' : ''; ?>>已完成</option>
                        <option value="已延期" <?php echo ($editData && $editData['status'] == '已延期') ? 'selected' : ''; ?>>已延期</option>
                        <option value="已取消" <?php echo ($editData && $editData['status'] == '已取消') ? 'selected' : ''; ?>>已取消</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>執行進度 (%) *</label>
                    <input type="range" name="progress" id="formProgress" min="0" max="100" step="5"
                           value="<?php echo $editData ? $editData['progress'] : '0'; ?>"
                           oninput="document.getElementById('progressValue').textContent = this.value + '%'">
                    <div style="text-align: center; margin-top: 5px; font-size: 18px; font-weight: 600; color: #667eea;">
                        <span id="progressValue"><?php echo $editData ? $editData['progress'] : '0'; ?>%</span>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 25px;">
                <button type="submit" class="btn btn-success">
                    ✓ <?php echo $editData ? '更新' : '新增'; ?>
                </button>
                <button type="button" class="btn" onclick="closeModal()">✗ 取消</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAddModal() {
    document.getElementById('formModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '新增行動方案';
    document.getElementById('formAction').value = 'add';
    document.getElementById('formId').value = '';
    document.getElementById('planForm').reset();
    document.getElementById('progressValue').textContent = '0%';
}

function editPlan(data) {
    document.getElementById('formModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '編輯行動方案';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('formId').value = data.id;
    document.getElementById('formObjective').value = data.objective_id;
    document.getElementById('formName').value = data.name;
    document.getElementById('formDescription').value = data.description || '';
    document.getElementById('formResponsible').value = data.responsible_person;
    document.getElementById('formBudget').value = data.budget;
    document.getElementById('formStartDate').value = data.start_date;
    document.getElementById('formEndDate').value = data.end_date;
    document.getElementById('formStatus').value = data.status;
    document.getElementById('formProgress').value = data.progress;
    document.getElementById('progressValue').textContent = data.progress + '%';
}

function closeModal() {
    document.getElementById('formModal').style.display = 'none';
}

document.getElementById('formModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

<?php if ($editData): ?>
document.getElementById('formModal').style.display = 'block';
<?php endif; ?>
</script>

<?php
$conn->close();
renderFooter();
?>