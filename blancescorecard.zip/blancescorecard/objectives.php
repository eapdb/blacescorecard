<?php
/**
 * 平衡計分卡管理系統 - 策略目標管理
 * 管理策略目標的新增、編輯、刪除
 */
require_once 'config.php';

$conn = getDbConnection();

$message = '';
$editData = null;

// 處理新增
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $perspective_id = (int)$_POST['perspective_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $weight = (float)$_POST['weight'];
    $order = (int)$_POST['display_order'];
    
    $sql = "INSERT INTO strategic_objectives (perspective_id, name, description, weight, display_order) 
            VALUES ($perspective_id, '$name', '$desc', $weight, $order)";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 策略目標新增成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 新增失敗：" . $conn->error . "</div>";
    }
}

// 處理編輯
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)$_POST['id'];
    $perspective_id = (int)$_POST['perspective_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $weight = (float)$_POST['weight'];
    $order = (int)$_POST['display_order'];
    
    $sql = "UPDATE strategic_objectives 
            SET perspective_id=$perspective_id, name='$name', description='$desc', 
                weight=$weight, display_order=$order
            WHERE id=$id";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 策略目標更新成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 更新失敗：" . $conn->error . "</div>";
    }
}

// 處理刪除
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // 檢查是否有關聯的KPI
    $check = fetchOne($conn, "SELECT COUNT(*) as count FROM kpis WHERE objective_id = $id");
    
    if ($check['count'] > 0) {
        $message = "<div class='alert alert-error'>✗ 無法刪除：此目標下還有 {$check['count']} 個KPI，請先刪除相關KPI。</div>";
    } else {
        if (safeQuery($conn, "DELETE FROM strategic_objectives WHERE id = $id")) {
            $message = "<div class='alert alert-success'>✓ 策略目標刪除成功！</div>";
        }
    }
}

// 取得編輯資料
if (isset($_GET['edit'])) {
    $editData = fetchOne($conn, "SELECT * FROM strategic_objectives WHERE id = " . (int)$_GET['edit']);
}

// 查詢所有構面（用於下拉選單）
$perspectives = fetchAll($conn, "SELECT * FROM perspectives ORDER BY display_order");

// 查詢所有策略目標
$objectives = fetchAll($conn, "
    SELECT 
        so.*,
        p.name as perspective_name,
        p.color,
        COUNT(DISTINCT k.id) as kpi_count,
        COUNT(DISTINCT ap.id) as action_plan_count,
        ROUND(AVG(kr.achievement_rate), 2) as avg_achievement
    FROM strategic_objectives so
    JOIN perspectives p ON so.perspective_id = p.id
    LEFT JOIN kpis k ON so.id = k.objective_id
    LEFT JOIN action_plans ap ON so.id = ap.objective_id
    LEFT JOIN kpi_records kr ON k.id = kr.kpi_id 
        AND kr.record_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
    GROUP BY so.id
    ORDER BY p.display_order, so.display_order
");

renderHeader('策略目標管理');
?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 30px 0;">
        <h1 style="font-size: 32px; color: #333;">🎯 策略目標管理</h1>
        <button onclick="openAddModal()" class="btn">
            ➕ 新增策略目標
        </button>
    </div>
    
    <?php echo $message; ?>
    
    <div class="alert alert-info">
        <strong>💡 策略目標說明：</strong> 策略目標是組織在各構面下期望達成的具體目標，每個構面可包含多個策略目標。建議為每個目標設定適當的權重，總和為100%。
    </div>
    
    <!-- 按構面分組顯示 -->
    <?php
    $objByPerspective = [];
    foreach ($objectives as $obj) {
        $objByPerspective[$obj['perspective_id']][] = $obj;
    }
    
    foreach ($perspectives as $persp):
        $perspObjs = $objByPerspective[$persp['id']] ?? [];
        if (count($perspObjs) === 0) continue;
    ?>
    
    <div class="card" style="border-left: 5px solid <?php echo $persp['color']; ?>;">
        <h2 style="color: <?php echo $persp['color']; ?>;">
            <?php echo htmlspecialchars($persp['name']); ?>
        </h2>
        
        <table style="margin-top: 20px;">
            <thead>
                <tr>
                    <th style="width: 60px;">順序</th>
                    <th>目標名稱</th>
                    <th style="width: 200px;">目標說明</th>
                    <th style="width: 80px;">權重</th>
                    <th style="width: 80px;">KPI數</th>
                    <th style="width: 80px;">方案數</th>
                    <th style="width: 100px;">達成率</th>
                    <th style="width: 160px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($perspObjs as $obj): ?>
                <tr>
                    <td style="text-align: center; font-weight: 600;">
                        <?php echo $obj['display_order']; ?>
                    </td>
                    <td>
                        <strong><?php echo htmlspecialchars($obj['name']); ?></strong>
                    </td>
                    <td style="font-size: 13px; color: #666;">
                        <?php echo htmlspecialchars(mb_substr($obj['description'], 0, 50)) . (mb_strlen($obj['description']) > 50 ? '...' : ''); ?>
                    </td>
                    <td style="text-align: center;">
                        <span class="badge badge-info">
                            <?php echo formatNumber($obj['weight']); ?>%
                        </span>
                    </td>
                    <td style="text-align: center; font-size: 18px; font-weight: 600; color: #667eea;">
                        <?php echo $obj['kpi_count']; ?>
                    </td>
                    <td style="text-align: center; font-size: 18px; font-weight: 600; color: #f39c12;">
                        <?php echo $obj['action_plan_count']; ?>
                    </td>
                    <td style="text-align: center;">
                        <?php if ($obj['avg_achievement'] !== null): ?>
                            <span style="color: <?php echo getAchievementColor($obj['avg_achievement']); ?>; font-weight: 600; font-size: 16px;">
                                <?php echo formatNumber($obj['avg_achievement']); ?>%
                            </span>
                        <?php else: ?>
                            <span style="color: #999;">-</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button onclick="editObjective(<?php echo htmlspecialchars(json_encode($obj)); ?>)" 
                                class="btn btn-small btn-warning">
                            ✏️ 編輯
                        </button>
                        <a href="?delete=<?php echo $obj['id']; ?>" 
                           class="btn btn-small btn-danger"
                           onclick="return confirm('確定要刪除「<?php echo htmlspecialchars($obj['name']); ?>」嗎？')">
                            🗑️ 刪除
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <?php endforeach; ?>
    
    <?php if (count($objectives) === 0): ?>
    <div class="card">
        <p style="text-align: center; color: #999; padding: 40px;">
            目前沒有任何策略目標，請點選「新增策略目標」開始建立。
        </p>
    </div>
    <?php endif; ?>
</div>

<!-- 新增/編輯視窗 -->
<div id="formModal" style="display: <?php echo $editData ? 'block' : 'none'; ?>; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
    <div style="position: relative; max-width: 700px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
        <h2 id="formTitle" style="margin-bottom: 20px;">
            <?php echo $editData ? '編輯策略目標' : '新增策略目標'; ?>
        </h2>
        
        <form method="POST" id="objectiveForm">
            <input type="hidden" name="action" id="formAction" value="<?php echo $editData ? 'edit' : 'add'; ?>">
            <input type="hidden" name="id" id="formId" value="<?php echo $editData ? $editData['id'] : ''; ?>">
            
            <div class="form-group">
                <label>所屬構面 *</label>
                <select name="perspective_id" id="formPerspective" required>
                    <option value="">請選擇構面</option>
                    <?php foreach ($perspectives as $persp): ?>
                        <option value="<?php echo $persp['id']; ?>"
                                <?php echo ($editData && $editData['perspective_id'] == $persp['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($persp['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>目標名稱 *</label>
                <input type="text" name="name" id="formName" required 
                       value="<?php echo $editData ? htmlspecialchars($editData['name']) : ''; ?>"
                       placeholder="例如：提升營收成長率">
            </div>
            
            <div class="form-group">
                <label>目標說明</label>
                <textarea name="description" id="formDescription" rows="4" 
                          placeholder="詳細描述此策略目標的內容與期望達成的效果..."><?php echo $editData ? htmlspecialchars($editData['description']) : ''; ?></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>權重 (%) *</label>
                    <input type="number" name="weight" id="formWeight" required min="0" max="100" step="0.01"
                           value="<?php echo $editData ? $editData['weight'] : '25.00'; ?>">
                    <small style="color: #999;">同構面下所有目標權重總和建議為100%</small>
                </div>
                
                <div class="form-group">
                    <label>顯示順序 *</label>
                    <input type="number" name="display_order" id="formOrder" required min="1"
                           value="<?php echo $editData ? $editData['display_order'] : '1'; ?>">
                    <small style="color: #999;">數字越小越靠前顯示</small>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 25px;">
                <button type="submit" class="btn btn-success">
                    ✓ <?php echo $editData ? '更新' : '新增'; ?>
                </button>
                <button type="button" class="btn" onclick="closeModal()">
                    ✗ 取消
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// 開啟新增視窗
function openAddModal() {
    document.getElementById('formModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '新增策略目標';
    document.getElementById('formAction').value = 'add';
    document.getElementById('formId').value = '';
    document.getElementById('objectiveForm').reset();
}

// 編輯策略目標
function editObjective(data) {
    document.getElementById('formModal').style.display = 'block';
    document.getElementById('formTitle').textContent = '編輯策略目標';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('formId').value = data.id;
    document.getElementById('formPerspective').value = data.perspective_id;
    document.getElementById('formName').value = data.name;
    document.getElementById('formDescription').value = data.description || '';
    document.getElementById('formWeight').value = data.weight;
    document.getElementById('formOrder').value = data.display_order;
}

// 關閉視窗
function closeModal() {
    document.getElementById('formModal').style.display = 'none';
}

// 點擊背景關閉
document.getElementById('formModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});

<?php if ($editData): ?>
// 自動開啟編輯視窗
document.getElementById('formModal').style.display = 'block';
<?php endif; ?>
</script>

<?php
$conn->close();
renderFooter();
?>