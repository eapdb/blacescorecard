<?php
/**
 * 平衡計分卡管理系統 - 儀表板
 * 顯示各構面的績效摘要和視覺化圖表
 */
require_once 'config.php';

$conn = getDbConnection();

// 查詢各構面的績效摘要
$perspective_summary = fetchAll($conn, "
    SELECT 
        p.id,
        p.name,
        p.color,
        COUNT(DISTINCT so.id) as objective_count,
        COUNT(DISTINCT k.id) as kpi_count,
        ROUND(AVG(kr.achievement_rate), 2) as avg_achievement_rate,
        COUNT(DISTINCT CASE WHEN ap.status = '執行中' THEN ap.id END) as active_plans
    FROM perspectives p
    LEFT JOIN strategic_objectives so ON p.id = so.perspective_id
    LEFT JOIN kpis k ON so.id = k.objective_id
    LEFT JOIN (
        SELECT kr1.*
        FROM kpi_records kr1
        INNER JOIN (
            SELECT kpi_id, MAX(record_date) as max_date
            FROM kpi_records
            GROUP BY kpi_id
        ) kr2 ON kr1.kpi_id = kr2.kpi_id AND kr1.record_date = kr2.max_date
    ) kr ON k.id = kr.kpi_id
    LEFT JOIN action_plans ap ON so.id = ap.objective_id
    GROUP BY p.id, p.name, p.color, p.display_order
    ORDER BY p.display_order
");

// 查詢各構面下的最新KPI達成狀況
$kpi_status_by_perspective = [];
foreach ($perspective_summary as $persp) {
    $kpi_status_by_perspective[$persp['id']] = fetchAll($conn, "
        SELECT 
            k.name as kpi_name,
            k.unit,
            k.target_value,
            kr.actual_value,
            kr.achievement_rate,
            kr.record_date
        FROM kpis k
        INNER JOIN strategic_objectives so ON k.objective_id = so.id
        INNER JOIN (
            SELECT kr1.*
            FROM kpi_records kr1
            INNER JOIN (
                SELECT kpi_id, MAX(record_date) as max_date
                FROM kpi_records
                GROUP BY kpi_id
            ) kr2 ON kr1.kpi_id = kr2.kpi_id AND kr1.record_date = kr2.max_date
        ) kr ON k.id = kr.kpi_id
        WHERE so.perspective_id = {$persp['id']}
        ORDER BY kr.achievement_rate DESC
    ");
}

// 查詢KPI趨勢資料（最近6個月）
$trend_data = fetchAll($conn, "
    SELECT 
        DATE_FORMAT(kr.record_date, '%Y-%m') as month,
        p.name as perspective_name,
        ROUND(AVG(kr.achievement_rate), 2) as avg_rate
    FROM kpi_records kr
    JOIN kpis k ON kr.kpi_id = k.id
    JOIN strategic_objectives so ON k.objective_id = so.id
    JOIN perspectives p ON so.perspective_id = p.id
    WHERE kr.record_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(kr.record_date, '%Y-%m'), p.id, p.name
    ORDER BY month, p.display_order
");

// 整理趨勢資料為圖表格式
$chart_months = [];
$chart_data = [];
foreach ($trend_data as $row) {
    if (!in_array($row['month'], $chart_months)) {
        $chart_months[] = $row['month'];
    }
    if (!isset($chart_data[$row['perspective_name']])) {
        $chart_data[$row['perspective_name']] = [];
    }
    $chart_data[$row['perspective_name']][$row['month']] = $row['avg_rate'];
}

renderHeader('儀表板');
?>

<div class="container">
    <h1 style="margin: 30px 0; font-size: 32px; color: #333;">📊 績效儀表板</h1>
    
    <div class="alert alert-info">
        <strong>📅 資料更新時間：</strong> <?php echo date('Y-m-d H:i:s'); ?>
    </div>
    
    <!-- 構面績效摘要 -->
    <div class="grid">
        <?php foreach ($perspective_summary as $persp): ?>
        <div class="card" style="border-left: 5px solid <?php echo $persp['color']; ?>;">
            <h3 style="color: <?php echo $persp['color']; ?>; margin-bottom: 15px;">
                <?php echo htmlspecialchars($persp['name']); ?>
            </h3>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 15px 0;">
                <div>
                    <p style="color: #999; font-size: 13px;">策略目標</p>
                    <p style="font-size: 24px; font-weight: 600; color: #333;">
                        <?php echo $persp['objective_count']; ?> 個
                    </p>
                </div>
                <div>
                    <p style="color: #999; font-size: 13px;">關鍵指標</p>
                    <p style="font-size: 24px; font-weight: 600; color: #333;">
                        <?php echo $persp['kpi_count']; ?> 個
                    </p>
                </div>
                <div>
                    <p style="color: #999; font-size: 13px;">執行中方案</p>
                    <p style="font-size: 24px; font-weight: 600; color: #333;">
                        <?php echo $persp['active_plans']; ?> 個
                    </p>
                </div>
                <div>
                    <p style="color: #999; font-size: 13px;">平均達成率</p>
                    <p style="font-size: 24px; font-weight: 600; color: <?php echo getAchievementColor($persp['avg_achievement_rate'] ?? 0); ?>;">
                        <?php echo formatNumber($persp['avg_achievement_rate'] ?? 0); ?>%
                    </p>
                </div>
            </div>
            
            <!-- 達成率進度條 -->
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo min($persp['avg_achievement_rate'] ?? 0, 100); ?>%; background: <?php echo $persp['color']; ?>;">
                    <?php if ($persp['avg_achievement_rate'] > 0): ?>
                        <?php echo formatNumber($persp['avg_achievement_rate']); ?>%
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- 趨勢圖表 -->
    <div class="card">
        <h2>📈 績效趨勢分析（最近6個月）</h2>
        <canvas id="trendChart" style="max-height: 400px; margin-top: 20px;"></canvas>
    </div>
    
    <!-- 各構面KPI詳細狀況 -->
    <?php foreach ($perspective_summary as $persp): ?>
        <?php if (isset($kpi_status_by_perspective[$persp['id']]) && count($kpi_status_by_perspective[$persp['id']]) > 0): ?>
        <div class="card">
            <h2 style="color: <?php echo $persp['color']; ?>;">
                <?php echo htmlspecialchars($persp['name']); ?> - KPI達成狀況
            </h2>
            <table>
                <thead>
                    <tr>
                        <th>KPI名稱</th>
                        <th>目標值</th>
                        <th>實際值</th>
                        <th>達成率</th>
                        <th>更新日期</th>
                        <th>狀態</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kpi_status_by_perspective[$persp['id']] as $kpi): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($kpi['kpi_name']); ?></strong></td>
                        <td><?php echo formatNumber($kpi['target_value']); ?> <?php echo htmlspecialchars($kpi['unit']); ?></td>
                        <td><?php echo formatNumber($kpi['actual_value']); ?> <?php echo htmlspecialchars($kpi['unit']); ?></td>
                        <td>
                            <span style="color: <?php echo getAchievementColor($kpi['achievement_rate']); ?>; font-weight: 600;">
                                <?php echo formatNumber($kpi['achievement_rate']); ?>%
                            </span>
                        </td>
                        <td><?php echo formatDate($kpi['record_date']); ?></td>
                        <td>
                            <?php if ($kpi['achievement_rate'] >= 100): ?>
                                <span class="badge badge-success">✓ 已達標</span>
                            <?php elseif ($kpi['achievement_rate'] >= 80): ?>
                                <span class="badge badge-warning">⚠ 接近目標</span>
                            <?php else: ?>
                                <span class="badge badge-danger">✗ 需改善</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>
    
    <!-- 績效雷達圖 -->
    <div class="card">
        <h2>🎯 四大構面績效雷達圖</h2>
        <canvas id="radarChart" style="max-height: 500px; margin-top: 20px;"></canvas>
    </div>
</div>

<!-- 引入Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
// 趨勢圖表
const trendCtx = document.getElementById('trendChart').getContext('2d');
const trendChart = new Chart(trendCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($chart_months); ?>,
        datasets: [
            <?php 
            $colors = ['#2ecc71', '#3498db', '#e74c3c', '#f39c12'];
            $i = 0;
            foreach ($chart_data as $perspective => $data): 
            ?>
            {
                label: '<?php echo $perspective; ?>',
                data: <?php echo json_encode(array_values($data)); ?>,
                borderColor: '<?php echo $colors[$i % 4]; ?>',
                backgroundColor: '<?php echo $colors[$i % 4]; ?>33',
                tension: 0.4,
                fill: true
            },
            <?php 
            $i++;
            endforeach; 
            ?>
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            title: {
                display: false
            },
            legend: {
                position: 'top',
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                max: 120,
                ticks: {
                    callback: function(value) {
                        return value + '%';
                    }
                }
            }
        }
    }
});

// 雷達圖
const radarCtx = document.getElementById('radarChart').getContext('2d');
const radarChart = new Chart(radarCtx, {
    type: 'radar',
    data: {
        labels: [
            <?php foreach ($perspective_summary as $persp): ?>
            '<?php echo $persp['name']; ?>',
            <?php endforeach; ?>
        ],
        datasets: [{
            label: '目前達成率',
            data: [
                <?php foreach ($perspective_summary as $persp): ?>
                <?php echo $persp['avg_achievement_rate'] ?? 0; ?>,
                <?php endforeach; ?>
            ],
            backgroundColor: 'rgba(102, 126, 234, 0.2)',
            borderColor: 'rgba(102, 126, 234, 1)',
            pointBackgroundColor: 'rgba(102, 126, 234, 1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(102, 126, 234, 1)'
        }, {
            label: '目標值',
            data: [100, 100, 100, 100],
            backgroundColor: 'rgba(46, 204, 113, 0.1)',
            borderColor: 'rgba(46, 204, 113, 1)',
            borderDash: [5, 5],
            pointBackgroundColor: 'rgba(46, 204, 113, 1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(46, 204, 113, 1)'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        scales: {
            r: {
                beginAtZero: true,
                max: 120,
                ticks: {
                    stepSize: 20,
                    callback: function(value) {
                        return value + '%';
                    }
                }
            }
        },
        plugins: {
            legend: {
                position: 'top',
            }
        }
    }
});
</script>

<?php
$conn->close();
renderFooter();
?>