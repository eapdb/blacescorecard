<?php
/**
 * 平衡計分卡管理系統 - KPI管理
 * 管理KPI的新增、編輯、刪除，以及實際值記錄
 */
require_once 'config.php';

$conn = getDbConnection();

$message = '';
$editData = null;

// 處理KPI新增
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_kpi') {
    $objective_id = (int)$_POST['objective_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $unit = $conn->real_escape_string($_POST['unit']);
    $target = (float)$_POST['target_value'];
    $weight = (float)$_POST['weight'];
    $frequency = $conn->real_escape_string($_POST['frequency']);
    $calculation = $conn->real_escape_string($_POST['calculation_method']);
    $source = $conn->real_escape_string($_POST['data_source']);
    
    $sql = "INSERT INTO kpis (objective_id, name, description, unit, target_value, weight, frequency, calculation_method, data_source) 
            VALUES ($objective_id, '$name', '$desc', '$unit', $target, $weight, '$frequency', '$calculation', '$source')";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ KPI新增成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 新增失敗：" . $conn->error . "</div>";
    }
}

// 處理KPI編輯
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_kpi') {
    $id = (int)$_POST['id'];
    $objective_id = (int)$_POST['objective_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $desc = $conn->real_escape_string($_POST['description']);
    $unit = $conn->real_escape_string($_POST['unit']);
    $target = (float)$_POST['target_value'];
    $weight = (float)$_POST['weight'];
    $frequency = $conn->real_escape_string($_POST['frequency']);
    $calculation = $conn->real_escape_string($_POST['calculation_method']);
    $source = $conn->real_escape_string($_POST['data_source']);
    
    $sql = "UPDATE kpis 
            SET objective_id=$objective_id, name='$name', description='$desc', unit='$unit', 
                target_value=$target, weight=$weight, frequency='$frequency', 
                calculation_method='$calculation', data_source='$source'
            WHERE id=$id";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ KPI更新成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 更新失敗：" . $conn->error . "</div>";
    }
}

// 處理KPI刪除
if (isset($_GET['delete_kpi'])) {
    $id = (int)$_GET['delete_kpi'];
    if (safeQuery($conn, "DELETE FROM kpis WHERE id = $id")) {
        $message = "<div class='alert alert-success'>✓ KPI刪除成功！</div>";
    }
}

// 處理實際值新增
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_record') {
    $kpi_id = (int)$_POST['kpi_id'];
    $date = $conn->real_escape_string($_POST['record_date']);
    $actual = (float)$_POST['actual_value'];
    $notes = $conn->real_escape_string($_POST['notes']);
    $creator = $conn->real_escape_string($_POST['created_by']);
    
    // 取得目標值計算達成率
    $kpi = fetchOne($conn, "SELECT target_value FROM kpis WHERE id = $kpi_id");
    $achievement = calculateAchievementRate($actual, $kpi['target_value']);
    
    $sql = "INSERT INTO kpi_records (kpi_id, record_date, actual_value, achievement_rate, notes, created_by) 
            VALUES ($kpi_id, '$date', $actual, $achievement, '$notes', '$creator')
            ON DUPLICATE KEY UPDATE actual_value=$actual, achievement_rate=$achievement, notes='$notes', created_by='$creator'";
    
    if (safeQuery($conn, $sql)) {
        $message = "<div class='alert alert-success'>✓ 實際值記錄成功！</div>";
    } else {
        $message = "<div class='alert alert-error'>✗ 記錄失敗：" . $conn->error . "</div>";
    }
}

// 處理實際值刪除
if (isset($_GET['delete_record'])) {
    $id = (int)$_GET['delete_record'];
    if (safeQuery($conn, "DELETE FROM kpi_records WHERE id = $id")) {
        $message = "<div class='alert alert-success'>✓ 記錄刪除成功！</div>";
    }
}

// 取得編輯資料
if (isset($_GET['edit_kpi'])) {
    $editData = fetchOne($conn, "SELECT * FROM kpis WHERE id = " . (int)$_GET['edit_kpi']);
}

// 查詢所有構面和目標（用於下拉選單）
$perspectives = fetchAll($conn, "SELECT * FROM perspectives ORDER BY display_order");
$objectives = fetchAll($conn, "
    SELECT so.*, p.name as perspective_name 
    FROM strategic_objectives so
    JOIN perspectives p ON so.perspective_id = p.id
    ORDER BY p.display_order, so.display_order
");

// 查詢所有KPI及其最新記錄
$kpis = fetchAll($conn, "
    SELECT 
        k.*,
        so.name as objective_name,
        p.name as perspective_name,
        p.color,
        kr.record_date as last_record_date,
        kr.actual_value as last_actual,
        kr.achievement_rate as last_achievement,
        (SELECT COUNT(*) FROM kpi_records WHERE kpi_id = k.id) as record_count
    FROM kpis k
    JOIN strategic_objectives so ON k.objective_id = so.id
    JOIN perspectives p ON so.perspective_id = p.id
    LEFT JOIN (
        SELECT kr1.*
        FROM kpi_records kr1
        INNER JOIN (
            SELECT kpi_id, MAX(record_date) as max_date
            FROM kpi_records
            GROUP BY kpi_id
        ) kr2 ON kr1.kpi_id = kr2.kpi_id AND kr1.record_date = kr2.max_date
    ) kr ON k.id = kr.kpi_id
    ORDER BY p.display_order, so.display_order, k.id
");

// 若指定KPI，查詢其歷史記錄
$selectedKpiId = isset($_GET['view_records']) ? (int)$_GET['view_records'] : null;
$kpiRecords = [];
if ($selectedKpiId) {
    $kpiRecords = fetchAll($conn, "
        SELECT * FROM kpi_records 
        WHERE kpi_id = $selectedKpiId 
        ORDER BY record_date DESC
    ");
}

renderHeader('KPI管理');
?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 30px 0;">
        <h1 style="font-size: 32px; color: #333;">📈 KPI管理</h1>
        <div style="display: flex; gap: 10px;">
            <button onclick="openAddKpiModal()" class="btn">
                ➕ 新增KPI
            </button>
            <button onclick="openAddRecordModal()" class="btn btn-success">
                📝 記錄實際值
            </button>
        </div>
    </div>
    
    <?php echo $message; ?>
    
    <div class="alert alert-info">
        <strong>💡 KPI說明：</strong> 關鍵績效指標(KPI)用於量化衡量策略目標的達成狀況。請為每個KPI設定明確的目標值、單位、衡量頻率，並定期記錄實際值。
    </div>
    
    <!-- KPI列表 -->
    <div class="card">
        <h2>📊 KPI列表</h2>
        <?php if (count($kpis) > 0): ?>
        <table style="margin-top: 20px;">
            <thead>
                <tr>
                    <th>構面</th>
                    <th>策略目標</th>
                    <th>KPI名稱</th>
                    <th>目標值</th>
                    <th>最新實際值</th>
                    <th>達成率</th>
                    <th>衡量頻率</th>
                    <th>記錄數</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($kpis as $kpi): ?>
                <tr>
                    <td>
                        <span style="display: inline-block; width: 8px; height: 8px; background: <?php echo $kpi['color']; ?>; border-radius: 50%; margin-right: 5px;"></span>
                        <?php echo htmlspecialchars($kpi['perspective_name']); ?>
                    </td>
                    <td style="font-size: 13px;">
                        <?php echo htmlspecialchars($kpi['objective_name']); ?>
                    </td>
                    <td><strong><?php echo htmlspecialchars($kpi['name']); ?></strong></td>
                    <td style="text-align: right;">
                        <?php echo formatNumber($kpi['target_value']); ?> 
                        <?php echo htmlspecialchars($kpi['unit']); ?>
                    </td>
                    <td style="text-align: right;">
                        <?php if ($kpi['last_actual'] !== null): ?>
                            <?php echo formatNumber($kpi['last_actual']); ?> 
                            <?php echo htmlspecialchars($kpi['unit']); ?>
                            <br><small style="color: #999;"><?php echo formatDate($kpi['last_record_date']); ?></small>
                        <?php else: ?>
                            <span style="color: #999;">尚無記錄</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;">
                        <?php if ($kpi['last_achievement'] !== null): ?>
                            <span style="color: <?php echo getAchievementColor($kpi['last_achievement']); ?>; font-weight: 600; font-size: 16px;">
                                <?php echo formatNumber($kpi['last_achievement']); ?>%
                            </span>
                        <?php else: ?>
                            <span style="color: #999;">-</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;">
                        <span class="badge badge-info"><?php echo $kpi['frequency']; ?></span>
                    </td>
                    <td style="text-align: center; font-weight: 600; color: #667eea;">
                        <?php echo $kpi['record_count']; ?>
                    </td>
                    <td style="white-space: nowrap;">
                        <a href="?view_records=<?php echo $kpi['id']; ?>" class="btn btn-small">
                            📋 記錄
                        </a>
                        <button onclick="editKpi(<?php echo htmlspecialchars(json_encode($kpi)); ?>)" 
                                class="btn btn-small btn-warning">
                            ✏️
                        </button>
                        <a href="?delete_kpi=<?php echo $kpi['id']; ?>" 
                           class="btn btn-small btn-danger"
                           onclick="return confirm('確定要刪除此KPI嗎？\n注意：所有相關的實際值記錄也會一併刪除。')">
                            🗑️
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="text-align: center; color: #999; padding: 40px;">
            目前沒有任何KPI，請點選「新增KPI」開始建立。
        </p>
        <?php endif; ?>
    </div>
    
    <!-- KPI歷史記錄 -->
    <?php if ($selectedKpiId): ?>
        <?php $selectedKpi = fetchOne($conn, "
            SELECT k.*, so.name as objective_name, p.name as perspective_name 
            FROM kpis k 
            JOIN strategic_objectives so ON k.objective_id = so.id
            JOIN perspectives p ON so.perspective_id = p.id
            WHERE k.id = $selectedKpiId
        "); ?>
        
        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2>📝 <?php echo htmlspecialchars($selectedKpi['name']); ?> - 歷史記錄</h2>
                <a href="kpis.php" class="btn btn-small">✗ 關閉</a>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin: 15px 0;">
                <strong>目標值：</strong> <?php echo formatNumber($selectedKpi['target_value']); ?> <?php echo htmlspecialchars($selectedKpi['unit']); ?> | 
                <strong>衡量頻率：</strong> <?php echo $selectedKpi['frequency']; ?> | 
                <strong>資料來源：</strong> <?php echo htmlspecialchars($selectedKpi['data_source']); ?>
            </div>
            
            <?php if (count($kpiRecords) > 0): ?>
            <table style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th>記錄日期</th>
                        <th>實際值</th>
                        <th>達成率</th>
                        <th>備註</th>
                        <th>建立者</th>
                        <th>建立時間</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kpiRecords as $record): ?>
                    <tr>
                        <td><?php echo formatDate($record['record_date']); ?></td>
                        <td style="text-align: right; font-weight: 600;">
                            <?php echo formatNumber($record['actual_value']); ?> 
                            <?php echo htmlspecialchars($selectedKpi['unit']); ?>
                        </td>
                        <td style="text-align: center;">
                            <span style="color: <?php echo getAchievementColor($record['achievement_rate']); ?>; font-weight: 600; font-size: 16px;">
                                <?php echo formatNumber($record['achievement_rate']); ?>%
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($record['notes']); ?></td>
                        <td><?php echo htmlspecialchars($record['created_by']); ?></td>
                        <td><?php echo formatDate($record['created_at'], 'Y-m-d H:i'); ?></td>
                        <td>
                            <a href="?view_records=<?php echo $selectedKpiId; ?>&delete_record=<?php echo $record['id']; ?>" 
                               class="btn btn-small btn-danger"
                               onclick="return confirm('確定要刪除此記錄嗎？')">
                                🗑️ 刪除
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- 趨勢圖 -->
            <div style="margin-top: 30px;">
                <h3>📈 趨勢圖</h3>
                <canvas id="trendChart" style="max-height: 300px; margin-top: 15px;"></canvas>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
            <script>
            const ctx = document.getElementById('trendChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_reverse(array_column($kpiRecords, 'record_date'))); ?>,
                    datasets: [{
                        label: '實際值',
                        data: <?php echo json_encode(array_reverse(array_column($kpiRecords, 'actual_value'))); ?>,
                        borderColor: '#667eea',
                        backgroundColor: '#667eea33',
                        tension: 0.4,
                        fill: true
                    }, {
                        label: '目標值',
                        data: Array(<?php echo count($kpiRecords); ?>).fill(<?php echo $selectedKpi['target_value']; ?>),
                        borderColor: '#2ecc71',
                        borderDash: [5, 5],
                        tension: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: { position: 'top' }
                    }
                }
            });
            </script>
            
            <?php else: ?>
            <p style="text-align: center; color: #999; padding: 40px;">
                此KPI尚無歷史記錄
            </p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- 新增/編輯KPI視窗 -->
<div id="kpiModal" style="display: <?php echo $editData ? 'block' : 'none'; ?>; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
    <div style="position: relative; max-width: 800px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
        <h2 id="kpiFormTitle"><?php echo $editData ? '編輯KPI' : '新增KPI'; ?></h2>
        
        <form method="POST" id="kpiForm">
            <input type="hidden" name="action" id="kpiAction" value="<?php echo $editData ? 'edit_kpi' : 'add_kpi'; ?>">
            <input type="hidden" name="id" id="kpiId" value="<?php echo $editData ? $editData['id'] : ''; ?>">
            
            <div class="form-group">
                <label>所屬策略目標 *</label>
                <select name="objective_id" id="kpiObjective" required>
                    <option value="">請選擇策略目標</option>
                    <?php foreach ($objectives as $obj): ?>
                        <option value="<?php echo $obj['id']; ?>"
                                <?php echo ($editData && $editData['objective_id'] == $obj['id']) ? 'selected' : ''; ?>>
                            [<?php echo htmlspecialchars($obj['perspective_name']); ?>] 
                            <?php echo htmlspecialchars($obj['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>KPI名稱 *</label>
                <input type="text" name="name" id="kpiName" required 
                       value="<?php echo $editData ? htmlspecialchars($editData['name']) : ''; ?>"
                       placeholder="例如：年營收成長率">
            </div>
            
            <div class="form-group">
                <label>KPI說明</label>
                <textarea name="description" id="kpiDescription" rows="3"
                          placeholder="描述此KPI的定義與衡量意義..."><?php echo $editData ? htmlspecialchars($editData['description']) : ''; ?></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>單位 *</label>
                    <input type="text" name="unit" id="kpiUnit" required 
                           value="<?php echo $editData ? htmlspecialchars($editData['unit']) : ''; ?>"
                           placeholder="%、元、件">
                </div>
                
                <div class="form-group">
                    <label>目標值 *</label>
                    <input type="number" name="target_value" id="kpiTarget" required step="0.01"
                           value="<?php echo $editData ? $editData['target_value'] : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label>權重 (%) *</label>
                    <input type="number" name="weight" id="kpiWeight" required min="0" max="100" step="0.01"
                           value="<?php echo $editData ? $editData['weight'] : '100'; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label>衡量頻率 *</label>
                <select name="frequency" id="kpiFrequency" required>
                    <option value="月" <?php echo ($editData && $editData['frequency'] == '月') ? 'selected' : ''; ?>>月</option>
                    <option value="季" <?php echo ($editData && $editData['frequency'] == '季') ? 'selected' : ''; ?>>季</option>
                    <option value="半年" <?php echo ($editData && $editData['frequency'] == '半年') ? 'selected' : ''; ?>>半年</option>
                    <option value="年" <?php echo ($editData && $editData['frequency'] == '年') ? 'selected' : ''; ?>>年</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>計算方式</label>
                <textarea name="calculation_method" id="kpiCalculation" rows="2"
                          placeholder="描述此KPI的計算公式..."><?php echo $editData ? htmlspecialchars($editData['calculation_method']) : ''; ?></textarea>
            </div>
            
            <div class="form-group">
                <label>資料來源</label>
                <input type="text" name="data_source" id="kpiSource"
                       value="<?php echo $editData ? htmlspecialchars($editData['data_source']) : ''; ?>"
                       placeholder="例如：財務系統、CRM系統">
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 25px;">
                <button type="submit" class="btn btn-success">
                    ✓ <?php echo $editData ? '更新' : '新增'; ?>
                </button>
                <button type="button" class="btn" onclick="closeKpiModal()">✗ 取消</button>
            </div>
        </form>
    </div>
</div>

<!-- 新增實際值記錄視窗 -->
<div id="recordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto;">
    <div style="position: relative; max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
        <h2>📝 記錄實際值</h2>
        
        <form method="POST">
            <input type="hidden" name="action" value="add_record">
            
            <div class="form-group">
                <label>選擇KPI *</label>
                <select name="kpi_id" required>
                    <option value="">請選擇要記錄的KPI</option>
                    <?php foreach ($kpis as $kpi): ?>
                        <option value="<?php echo $kpi['id']; ?>">
                            [<?php echo htmlspecialchars($kpi['perspective_name']); ?>] 
                            <?php echo htmlspecialchars($kpi['name']); ?> 
                            (目標: <?php echo formatNumber($kpi['target_value']); ?> <?php echo $kpi['unit']; ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>記錄日期 *</label>
                <input type="date" name="record_date" required value="<?php echo date('Y-m-d'); ?>">
            </div>
            
            <div class="form-group">
                <label>實際值 *</label>
                <input type="number" name="actual_value" required step="0.01" placeholder="輸入實際數值">
            </div>
            
            <div class="form-group">
                <label>備註說明</label>
                <textarea name="notes" rows="3" placeholder="可記錄特殊狀況或說明..."></textarea>
            </div>
            
            <div class="form-group">
                <label>建立者 *</label>
                <input type="text" name="created_by" required placeholder="輸入您的姓名或部門">
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 25px;">
                <button type="submit" class="btn btn-success">✓ 儲存記錄</button>
                <button type="button" class="btn" onclick="closeRecordModal()">✗ 取消</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAddKpiModal() {
    document.getElementById('kpiModal').style.display = 'block';
    document.getElementById('kpiFormTitle').textContent = '新增KPI';
    document.getElementById('kpiAction').value = 'add_kpi';
    document.getElementById('kpiId').value = '';
    document.getElementById('kpiForm').reset();
}

function editKpi(data) {
    document.getElementById('kpiModal').style.display = 'block';
    document.getElementById('kpiFormTitle').textContent = '編輯KPI';
    document.getElementById('kpiAction').value = 'edit_kpi';
    document.getElementById('kpiId').value = data.id;
    document.getElementById('kpiObjective').value = data.objective_id;
    document.getElementById('kpiName').value = data.name;
    document.getElementById('kpiDescription').value = data.description || '';
    document.getElementById('kpiUnit').value = data.unit;
    document.getElementById('kpiTarget').value = data.target_value;
    document.getElementById('kpiWeight').value = data.weight;
    document.getElementById('kpiFrequency').value = data.frequency;
    document.getElementById('kpiCalculation').value = data.calculation_method || '';
    document.getElementById('kpiSource').value = data.data_source || '';
}

function closeKpiModal() {
    document.getElementById('kpiModal').style.display = 'none';
}

function openAddRecordModal() {
    document.getElementById('recordModal').style.display = 'block';
}

function closeRecordModal() {
    document.getElementById('recordModal').style.display = 'none';
}

document.getElementById('kpiModal').addEventListener('click', function(e) {
    if (e.target === this) closeKpiModal();
});

document.getElementById('recordModal').addEventListener('click', function(e) {
    if (e.target === this) closeRecordModal();
});

<?php if ($editData): ?>
document.getElementById('kpiModal').style.display = 'block';
<?php endif; ?>
</script>

<?php
$conn->close();
renderFooter();
?>