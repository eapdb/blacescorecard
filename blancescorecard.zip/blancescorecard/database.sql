-- 平衡計分卡管理系統資料庫
CREATE DATABASE IF NOT EXISTS bsc_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bsc_system;

-- 1. 四大構面主檔
CREATE TABLE perspectives (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '構面名稱',
    description TEXT COMMENT '構面說明',
    display_order INT DEFAULT 0 COMMENT '顯示順序',
    color VARCHAR(20) DEFAULT '#3498db' COMMENT '顯示顏色',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='平衡計分卡四大構面';

-- 2. 策略目標
CREATE TABLE strategic_objectives (
    id INT PRIMARY KEY AUTO_INCREMENT,
    perspective_id INT NOT NULL COMMENT '所屬構面',
    name VARCHAR(200) NOT NULL COMMENT '目標名稱',
    description TEXT COMMENT '目標說明',
    weight DECIMAL(5,2) DEFAULT 25.00 COMMENT '權重(%)',
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perspective_id) REFERENCES perspectives(id) ON DELETE CASCADE
) COMMENT='策略目標';

-- 3. 關鍵績效指標(KPI)
CREATE TABLE kpis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    objective_id INT NOT NULL COMMENT '所屬策略目標',
    name VARCHAR(200) NOT NULL COMMENT 'KPI名稱',
    description TEXT COMMENT 'KPI說明',
    unit VARCHAR(50) COMMENT '單位(%, 元, 件等)',
    target_value DECIMAL(15,2) COMMENT '目標值',
    weight DECIMAL(5,2) DEFAULT 100.00 COMMENT '權重(%)',
    frequency ENUM('月', '季', '半年', '年') DEFAULT '月' COMMENT '衡量頻率',
    calculation_method TEXT COMMENT '計算方式',
    data_source VARCHAR(200) COMMENT '資料來源',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (objective_id) REFERENCES strategic_objectives(id) ON DELETE CASCADE
) COMMENT='關鍵績效指標';

-- 4. KPI實際值紀錄
CREATE TABLE kpi_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kpi_id INT NOT NULL COMMENT '所屬KPI',
    record_date DATE NOT NULL COMMENT '紀錄日期',
    actual_value DECIMAL(15,2) NOT NULL COMMENT '實際值',
    achievement_rate DECIMAL(5,2) COMMENT '達成率(%)',
    notes TEXT COMMENT '備註說明',
    created_by VARCHAR(100) COMMENT '建立者',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kpi_id) REFERENCES kpis(id) ON DELETE CASCADE,
    UNIQUE KEY unique_kpi_date (kpi_id, record_date)
) COMMENT='KPI實際值紀錄';

-- 5. 策略地圖關聯
CREATE TABLE strategy_map_relations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    from_objective_id INT NOT NULL COMMENT '來源目標',
    to_objective_id INT NOT NULL COMMENT '目的目標',
    relation_type ENUM('因果', '支援', '影響') DEFAULT '因果' COMMENT '關聯類型',
    description TEXT COMMENT '關聯說明',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_objective_id) REFERENCES strategic_objectives(id) ON DELETE CASCADE,
    FOREIGN KEY (to_objective_id) REFERENCES strategic_objectives(id) ON DELETE CASCADE
) COMMENT='策略地圖目標關聯';

-- 6. 行動方案
CREATE TABLE action_plans (
    id INT PRIMARY KEY AUTO_INCREMENT,
    objective_id INT NOT NULL COMMENT '所屬策略目標',
    name VARCHAR(200) NOT NULL COMMENT '方案名稱',
    description TEXT COMMENT '方案說明',
    responsible_person VARCHAR(100) COMMENT '負責人',
    start_date DATE COMMENT '開始日期',
    end_date DATE COMMENT '結束日期',
    budget DECIMAL(15,2) COMMENT '預算金額',
    status ENUM('規劃中', '執行中', '已完成', '已延期', '已取消') DEFAULT '規劃中',
    progress INT DEFAULT 0 COMMENT '進度(%)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (objective_id) REFERENCES strategic_objectives(id) ON DELETE CASCADE
) COMMENT='行動方案';

-- ==================== 插入範例資料 ====================

-- 插入四大構面
INSERT INTO perspectives (name, description, display_order, color) VALUES
('財務構面', '衡量企業財務績效與股東價值創造', 1, '#2ecc71'),
('顧客構面', '衡量顧客滿意度與市場佔有率', 2, '#3498db'),
('內部流程構面', '衡量內部作業流程效率與品質', 3, '#e74c3c'),
('學習與成長構面', '衡量組織創新能力與員工發展', 4, '#f39c12');

-- 插入策略目標
INSERT INTO strategic_objectives (perspective_id, name, description, weight, display_order) VALUES
-- 財務構面目標
(1, '提升營收成長率', '年營收成長率達15%以上', 30, 1),
(1, '改善獲利能力', '營業利益率提升至20%', 40, 2),
(1, '優化成本結構', '降低營運成本15%', 30, 3),

-- 顧客構面目標
(2, '提高顧客滿意度', '顧客滿意度達90分以上', 35, 1),
(2, '增加市場佔有率', '市場佔有率提升5%', 35, 2),
(2, '提升品牌價值', '品牌知名度提升20%', 30, 3),

-- 內部流程構面目標
(3, '提升生產效率', '生產週期縮短30%', 30, 1),
(3, '改善品質水準', '不良率降至1%以下', 40, 2),
(3, '強化創新能力', '新產品開發週期縮短25%', 30, 3),

-- 學習與成長構面目標
(4, '提升員工能力', '員工訓練時數達40小時/年', 35, 1),
(4, '強化組織文化', '員工滿意度達85分以上', 35, 2),
(4, '建立知識管理', '知識分享平台使用率達80%', 30, 3);

-- 插入KPI
INSERT INTO kpis (objective_id, name, description, unit, target_value, weight, frequency, calculation_method, data_source) VALUES
-- 財務構面KPI
(1, '年營收成長率', '相較去年同期營收成長百分比', '%', 15.00, 100, '月', '(本期營收-去年同期營收)/去年同期營收*100', '財務系統'),
(2, '營業利益率', '營業利益佔營收比例', '%', 20.00, 100, '月', '營業利益/營收*100', '財務系統'),
(3, '營運成本率', '營運成本佔營收比例', '%', 60.00, 100, '月', '營運成本/營收*100', '財務系統'),

-- 顧客構面KPI
(4, '顧客滿意度', '顧客滿意度調查平均分數', '分', 90.00, 100, '季', '滿意度問卷平均分數', 'CRM系統'),
(5, '市場佔有率', '產品在市場的佔有率', '%', 25.00, 100, '季', '公司銷售額/市場總銷售額*100', '市場調查'),
(6, '品牌知名度', '品牌認知度調查結果', '%', 75.00, 100, '半年', '品牌認知問卷統計', '市場調查'),

-- 內部流程構面KPI
(7, '生產週期時間', '從接單到交貨的平均天數', '天', 15.00, 100, '月', '訂單交貨時間平均值', 'ERP系統'),
(8, '產品不良率', '不良品數量佔總產量比例', '%', 1.00, 100, '月', '不良品數/總產量*100', '品質系統'),
(9, '新產品上市時間', '新產品從研發到上市平均天數', '天', 180.00, 100, '季', '新產品開發週期平均值', 'PLM系統'),

-- 學習與成長構面KPI
(10, '人均訓練時數', '員工年度平均受訓時數', '小時', 40.00, 100, '季', '總訓練時數/總員工數', 'HR系統'),
(11, '員工滿意度', '員工滿意度調查平均分數', '分', 85.00, 100, '半年', '員工滿意度問卷平均分數', 'HR系統'),
(12, '知識平台使用率', '使用知識管理平台的員工比例', '%', 80.00, 100, '月', '活躍用戶數/總員工數*100', 'KM系統');

-- 插入KPI實際值範例（最近3個月）
INSERT INTO kpi_records (kpi_id, record_date, actual_value, achievement_rate, notes, created_by) VALUES
-- 2024年9月資料
(1, '2024-09-30', 12.50, 83.33, '第三季營收穩定成長', '財務部'),
(2, '2024-09-30', 18.50, 92.50, '獲利能力持續改善', '財務部'),
(3, '2024-09-30', 62.00, 96.77, '成本控制良好', '財務部'),
(7, '2024-09-30', 18.00, 83.33, '生產效率有待提升', '生產部'),
(8, '2024-09-30', 1.20, 83.33, '品質管理需加強', '品管部'),

-- 2024年10月資料
(1, '2024-10-31', 13.80, 92.00, '旺季訂單增加', '財務部'),
(2, '2024-10-31', 19.20, 96.00, '營業利益穩定提升', '財務部'),
(3, '2024-10-31', 61.00, 98.36, '成本優化見效', '財務部'),
(7, '2024-10-31', 16.50, 90.91, '生產流程改善中', '生產部'),
(8, '2024-10-31', 1.10, 90.91, '品質改善方案執行中', '品管部'),
(10, '2024-10-31', 35.00, 87.50, '訓練計畫持續進行', 'HR部'),

-- 2024年11月資料
(1, '2024-11-14', 14.20, 94.67, '接近目標值', '財務部'),
(2, '2024-11-14', 19.80, 99.00, '表現優異', '財務部'),
(3, '2024-11-14', 60.50, 99.17, '成本控制達標', '財務部'),
(7, '2024-11-14', 15.80, 94.94, '生產效率大幅提升', '生產部'),
(8, '2024-11-14', 1.05, 95.24, '品質持續改善', '品管部'),
(12, '2024-11-14', 75.00, 93.75, '平台使用率提升', 'IT部');

-- 插入策略地圖關聯
INSERT INTO strategy_map_relations (from_objective_id, to_objective_id, relation_type, description) VALUES
-- 學習與成長 -> 內部流程
(10, 7, '因果', '員工能力提升有助於生產效率改善'),
(10, 8, '因果', '員工訓練提升品質意識'),
(11, 9, '支援', '良好組織文化促進創新'),

-- 內部流程 -> 顧客
(7, 4, '因果', '快速交貨提升顧客滿意度'),
(8, 4, '因果', '高品質產品增加顧客滿意'),
(9, 6, '因果', '創新產品提升品牌價值'),

-- 顧客 -> 財務
(4, 1, '因果', '顧客滿意帶動營收成長'),
(5, 1, '因果', '市場佔有率提升增加營收'),
(6, 2, '支援', '品牌價值提升改善獲利'),

-- 內部流程 -> 財務
(7, 3, '因果', '效率提升降低成本'),
(8, 3, '因果', '品質改善減少浪費成本');

-- 插入行動方案
INSERT INTO action_plans (objective_id, name, description, responsible_person, start_date, end_date, budget, status, progress) VALUES
(10, '年度教育訓練計畫', '規劃全年度員工專業技能與管理訓練課程', '人資部經理', '2024-01-01', '2024-12-31', 500000, '執行中', 85),
(7, '生產線自動化專案', '導入自動化設備提升生產效率', '生產部經理', '2024-03-01', '2024-12-31', 3000000, '執行中', 70),
(8, '品質改善專案', '實施六標準差品質管理方法', '品管部經理', '2024-02-01', '2024-11-30', 800000, '執行中', 80),
(4, '客戶關係強化計畫', '建立客戶定期訪談與回饋機制', '業務部經理', '2024-01-15', '2024-12-31', 300000, '執行中', 75),
(5, '市場拓展計畫', '開發新通路與新市場區域', '行銷部經理', '2024-04-01', '2025-03-31', 2000000, '執行中', 60),
(9, '新產品研發專案', '開發下一代智慧型產品', '研發部經理', '2024-01-01', '2025-06-30', 5000000, '執行中', 55);

-- 建立視圖：儀表板摘要資料
CREATE VIEW dashboard_summary AS
SELECT 
    p.name AS perspective_name,
    p.color,
    COUNT(DISTINCT so.id) AS objective_count,
    COUNT(DISTINCT k.id) AS kpi_count,
    ROUND(AVG(kr.achievement_rate), 2) AS avg_achievement_rate,
    COUNT(DISTINCT ap.id) AS action_plan_count
FROM perspectives p
LEFT JOIN strategic_objectives so ON p.id = so.perspective_id
LEFT JOIN kpis k ON so.id = k.objective_id
LEFT JOIN kpi_records kr ON k.id = kr.kpi_id AND kr.record_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
LEFT JOIN action_plans ap ON so.id = ap.objective_id AND ap.status = '執行中'
GROUP BY p.id, p.name, p.color, p.display_order
ORDER BY p.display_order;

-- 建立視圖：最新KPI達成狀況
CREATE VIEW latest_kpi_status AS
SELECT 
    p.name AS perspective_name,
    so.name AS objective_name,
    k.name AS kpi_name,
    k.unit,
    k.target_value,
    kr.actual_value,
    kr.achievement_rate,
    kr.record_date
FROM kpis k
INNER JOIN strategic_objectives so ON k.objective_id = so.id
INNER JOIN perspectives p ON so.perspective_id = p.id
INNER JOIN (
    SELECT kpi_id, MAX(record_date) AS max_date
    FROM kpi_records
    GROUP BY kpi_id
) latest ON k.id = latest.kpi_id
INNER JOIN kpi_records kr ON k.id = kr.kpi_id AND kr.record_date = latest.max_date
ORDER BY p.display_order, so.display_order;