<?php
/**
 * 平衡計分卡管理系統 - 首頁
 */
require_once 'config.php';

// 取得資料庫連線
$conn = getDbConnection();

// 查詢統計資料
$stats = [
    'perspectives' => fetchOne($conn, "SELECT COUNT(*) as count FROM perspectives")['count'],
    'objectives' => fetchOne($conn, "SELECT COUNT(*) as count FROM strategic_objectives")['count'],
    'kpis' => fetchOne($conn, "SELECT COUNT(*) as count FROM kpis")['count'],
    'action_plans' => fetchOne($conn, "SELECT COUNT(*) as count FROM action_plans WHERE status = '執行中'")['count']
];

// 查詢最近更新的KPI紀錄
$recent_records = fetchAll($conn, "
    SELECT 
        kr.record_date,
        k.name as kpi_name,
        p.name as perspective_name,
        kr.actual_value,
        k.unit,
        kr.achievement_rate,
        kr.created_by
    FROM kpi_records kr
    JOIN kpis k ON kr.kpi_id = k.id
    JOIN strategic_objectives so ON k.objective_id = so.id
    JOIN perspectives p ON so.perspective_id = p.id
    ORDER BY kr.created_at DESC
    LIMIT 10
");

renderHeader('系統首頁');
?>

<div class="container">
    <h1 style="margin: 30px 0; font-size: 32px; color: #333;">歡迎使用平衡計分卡管理系統</h1>
    
    <div class="alert alert-info">
        <strong>💡 系統說明：</strong> 本系統基於平衡計分卡（Balanced Scorecard, BSC）管理方法，協助組織從財務、顧客、內部流程、學習與成長四大構面，建立完整的策略管理體系。
    </div>
    
    <!-- 統計卡片 -->
    <div class="grid">
        <div class="card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <h3 style="font-size: 48px; margin-bottom: 10px; color: white;"><?php echo $stats['perspectives']; ?></h3>
            <p style="font-size: 18px; opacity: 0.9;">管理構面</p>
            <p style="margin-top: 10px; opacity: 0.8;">Perspectives</p>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
            <h3 style="font-size: 48px; margin-bottom: 10px; color: white;"><?php echo $stats['objectives']; ?></h3>
            <p style="font-size: 18px; opacity: 0.9;">策略目標</p>
            <p style="margin-top: 10px; opacity: 0.8;">Strategic Objectives</p>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
            <h3 style="font-size: 48px; margin-bottom: 10px; color: white;"><?php echo $stats['kpis']; ?></h3>
            <p style="font-size: 18px; opacity: 0.9;">關鍵績效指標</p>
            <p style="margin-top: 10px; opacity: 0.8;">KPIs</p>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
            <h3 style="font-size: 48px; margin-bottom: 10px; color: white;"><?php echo $stats['action_plans']; ?></h3>
            <p style="font-size: 18px; opacity: 0.9;">執行中方案</p>
            <p style="margin-top: 10px; opacity: 0.8;">Active Action Plans</p>
        </div>
    </div>
    
    <!-- 快速功能入口 -->
    <div class="card">
        <h2>🚀 快速功能</h2>
        <div class="grid" style="margin-top: 20px;">
            <a href="dashboard.php" class="btn" style="padding: 20px; text-align: center; display: block;">
                📊 查看儀表板<br>
                <small style="opacity: 0.8;">檢視整體績效表現</small>
            </a>
            <a href="strategy_map.php" class="btn btn-success" style="padding: 20px; text-align: center; display: block;">
                🗺️ 策略地圖<br>
                <small style="opacity: 0.8;">查看目標因果關係</small>
            </a>
            <a href="kpis.php" class="btn btn-warning" style="padding: 20px; text-align: center; display: block;">
                📈 KPI管理<br>
                <small style="opacity: 0.8;">管理績效指標</small>
            </a>
            <a href="action_plans.php" class="btn btn-danger" style="padding: 20px; text-align: center; display: block;">
                📋 行動方案<br>
                <small style="opacity: 0.8;">追蹤執行進度</small>
            </a>
        </div>
    </div>
    
    <!-- 最近更新 -->
    <div class="card">
        <h2>📝 最近更新的KPI紀錄</h2>
        <?php if (count($recent_records) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>日期</th>
                    <th>構面</th>
                    <th>KPI名稱</th>
                    <th>實際值</th>
                    <th>達成率</th>
                    <th>建立者</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_records as $record): ?>
                <tr>
                    <td><?php echo formatDate($record['record_date']); ?></td>
                    <td><?php echo htmlspecialchars($record['perspective_name']); ?></td>
                    <td><?php echo htmlspecialchars($record['kpi_name']); ?></td>
                    <td>
                        <?php echo formatNumber($record['actual_value']); ?> 
                        <?php echo htmlspecialchars($record['unit']); ?>
                    </td>
                    <td>
                        <span class="badge <?php 
                            if ($record['achievement_rate'] >= 100) echo 'badge-success';
                            elseif ($record['achievement_rate'] >= 80) echo 'badge-warning';
                            else echo 'badge-danger';
                        ?>">
                            <?php echo formatNumber($record['achievement_rate']); ?>%
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars($record['created_by']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="text-align: center; color: #999; padding: 20px;">目前沒有KPI紀錄</p>
        <?php endif; ?>
    </div>
    
    <!-- 系統功能說明 -->
    <div class="card">
        <h2>📖 系統功能說明</h2>
        <div class="grid">
            <div>
                <h3 style="color: #667eea; margin-bottom: 10px;">🎯 構面管理</h3>
                <p style="line-height: 1.8;">管理平衡計分卡的四大構面：財務構面、顧客構面、內部流程構面、學習與成長構面。每個構面可設定名稱、說明、顯示順序和顏色。</p>
            </div>
            <div>
                <h3 style="color: #667eea; margin-bottom: 10px;">🎯 目標管理</h3>
                <p style="line-height: 1.8;">在各構面下建立策略目標，設定目標說明、權重等資訊，形成組織的策略藍圖。</p>
            </div>
            <div>
                <h3 style="color: #667eea; margin-bottom: 10px;">📊 KPI管理</h3>
                <p style="line-height: 1.8;">為每個策略目標設定關鍵績效指標（KPI），包括目標值、單位、衡量頻率、計算方式等，並可持續記錄實際值與達成率。</p>
            </div>
            <div>
                <h3 style="color: #667eea; margin-bottom: 10px;">📋 行動方案</h3>
                <p style="line-height: 1.8;">針對策略目標規劃具體的行動方案，設定負責人、時程、預算，並追蹤執行進度與狀態。</p>
            </div>
            <div>
                <h3 style="color: #667eea; margin-bottom: 10px;">📈 儀表板</h3>
                <p style="line-height: 1.8;">以視覺化圖表呈現各構面的整體績效，快速掌握組織各層面的達成狀況。</p>
            </div>
            <div>
                <h3 style="color: #667eea; margin-bottom: 10px;">🗺️ 策略地圖</h3>
                <p style="line-height: 1.8;">呈現策略目標間的因果關係，展示從學習與成長到財務構面的策略邏輯鏈。</p>
            </div>
        </div>
    </div>
</div>

<?php
$conn->close();
renderFooter();
?>