<?php
/**
 * 平衡計分卡管理系統 - 資料庫連線設定
 */

// 資料庫連線參數
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bsc_system');
define('DB_CHARSET', 'utf8mb4');

// 系統設定
define('SITE_NAME', '平衡計分卡管理系統');
define('SITE_URL', 'http://localhost/bsc');
define('ADMIN_EMAIL', 'admin@company.com');

// 時區設定
date_default_timezone_set('Asia/Taipei');

/**
 * 建立資料庫連線
 * @return mysqli|false
 */
function getDbConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // 檢查連線
    if ($conn->connect_error) {
        die("資料庫連線失敗: " . $conn->connect_error);
    }
    
    // 設定字元集
    $conn->set_charset(DB_CHARSET);
    
    return $conn;
}

/**
 * 安全的SQL查詢
 * @param mysqli $conn 資料庫連線
 * @param string $sql SQL語句
 * @return mysqli_result|bool
 */
function safeQuery($conn, $sql) {
    $result = $conn->query($sql);
    if (!$result) {
        error_log("SQL錯誤: " . $conn->error . " | SQL: " . $sql);
    }
    return $result;
}

/**
 * 取得單筆資料
 * @param mysqli $conn 資料庫連線
 * @param string $sql SQL語句
 * @return array|null
 */
function fetchOne($conn, $sql) {
    $result = safeQuery($conn, $sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

/**
 * 取得多筆資料
 * @param mysqli $conn 資料庫連線
 * @param string $sql SQL語句
 * @return array
 */
function fetchAll($conn, $sql) {
    $data = [];
    $result = safeQuery($conn, $sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

/**
 * 格式化日期
 * @param string $date 日期字串
 * @param string $format 格式
 * @return string
 */
function formatDate($date, $format = 'Y-m-d') {
    if (empty($date)) return '-';
    return date($format, strtotime($date));
}

/**
 * 格式化數字
 * @param float $number 數字
 * @param int $decimals 小數位數
 * @return string
 */
function formatNumber($number, $decimals = 2) {
    if (is_null($number) || $number === '') return '-';
    return number_format($number, $decimals);
}

/**
 * 計算達成率
 * @param float $actual 實際值
 * @param float $target 目標值
 * @return float
 */
function calculateAchievementRate($actual, $target) {
    if ($target == 0) return 0;
    return round(($actual / $target) * 100, 2);
}

/**
 * 取得達成率顏色
 * @param float $rate 達成率
 * @return string
 */
function getAchievementColor($rate) {
    if ($rate >= 100) return '#2ecc71'; // 綠色
    if ($rate >= 80) return '#f39c12';  // 橘色
    return '#e74c3c'; // 紅色
}

/**
 * 產生HTML頁首
 * @param string $title 頁面標題
 */
function renderHeader($title = '') {
    $pageTitle = empty($title) ? SITE_NAME : $title . ' - ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Microsoft JhengHei', Arial, sans-serif; 
            background: #f5f7fa; 
            color: #333;
            line-height: 1.6;
        }
        .container { 
            max-width: 1400px; 
            margin: 0 auto; 
            padding: 20px; 
        }
        
        /* 導航列 */
        nav { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; 
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        nav .container { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        nav h1 { 
            font-size: 24px; 
            font-weight: 600;
        }
        nav ul { 
            list-style: none; 
            display: flex; 
            gap: 25px; 
        }
        nav a { 
            color: white; 
            text-decoration: none; 
            padding: 8px 16px;
            border-radius: 5px;
            transition: all 0.3s;
            font-weight: 500;
        }
        nav a:hover { 
            background: rgba(255,255,255,0.2);
            transform: translateY(-2px);
        }
        nav a.active {
            background: rgba(255,255,255,0.3);
        }
        
        /* 卡片樣式 */
        .card { 
            background: white; 
            border-radius: 12px; 
            padding: 25px; 
            margin: 20px 0;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 25px rgba(0,0,0,0.12);
        }
        .card h2 { 
            color: #667eea; 
            margin-bottom: 20px;
            font-size: 22px;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        /* 表格樣式 */
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 15px 0;
        }
        th, td { 
            padding: 12px; 
            text-align: left; 
            border-bottom: 1px solid #e0e0e0; 
        }
        th { 
            background: #f8f9fa; 
            font-weight: 600;
            color: #555;
        }
        tr:hover { 
            background: #f8f9fa; 
        }
        
        /* 按鈕樣式 */
        .btn { 
            display: inline-block;
            padding: 10px 20px; 
            background: #667eea; 
            color: white; 
            text-decoration: none; 
            border-radius: 6px; 
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
        }
        .btn:hover { 
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .btn-small { 
            padding: 6px 12px; 
            font-size: 13px; 
        }
        .btn-success { 
            background: #2ecc71; 
        }
        .btn-success:hover { 
            background: #27ae60; 
        }
        .btn-danger { 
            background: #e74c3c; 
        }
        .btn-danger:hover { 
            background: #c0392b; 
        }
        .btn-warning { 
            background: #f39c12; 
        }
        .btn-warning:hover { 
            background: #d68910; 
        }
        
        /* 表單樣式 */
        .form-group { 
            margin: 15px 0; 
        }
        .form-group label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: 600;
            color: #555;
        }
        .form-group input, 
        .form-group select, 
        .form-group textarea { 
            width: 100%; 
            padding: 10px; 
            border: 1px solid #ddd; 
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus, 
        .form-group select:focus, 
        .form-group textarea:focus { 
            outline: none; 
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        /* 網格佈局 */
        .grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 20px; 
        }
        
        /* 訊息提示 */
        .alert { 
            padding: 15px; 
            border-radius: 6px; 
            margin: 15px 0;
            font-weight: 500;
        }
        .alert-success { 
            background: #d4edda; 
            color: #155724; 
            border-left: 4px solid #28a745;
        }
        .alert-error { 
            background: #f8d7da; 
            color: #721c24; 
            border-left: 4px solid #dc3545;
        }
        .alert-info { 
            background: #d1ecf1; 
            color: #0c5460; 
            border-left: 4px solid #17a2b8;
        }
        
        /* 徽章樣式 */
        .badge { 
            display: inline-block;
            padding: 4px 10px; 
            border-radius: 12px; 
            font-size: 12px;
            font-weight: 600;
        }
        .badge-success { 
            background: #d4edda; 
            color: #155724; 
        }
        .badge-warning { 
            background: #fff3cd; 
            color: #856404; 
        }
        .badge-danger { 
            background: #f8d7da; 
            color: #721c24; 
        }
        
        /* 進度條 */
        .progress-bar { 
            width: 100%; 
            height: 20px; 
            background: #e0e0e0; 
            border-radius: 10px; 
            overflow: hidden;
        }
        .progress-fill { 
            height: 100%; 
            background: linear-gradient(90deg, #667eea, #764ba2);
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav>
        <div class="container">
            <h1>📊 <?php echo SITE_NAME; ?></h1>
            <ul>
                <li><a href="index.php">首頁</a></li>
                <li><a href="dashboard.php">儀表板</a></li>
                <li><a href="strategy_map.php">策略地圖</a></li>
                <li><a href="perspectives.php">構面管理</a></li>
                <li><a href="objectives.php">目標管理</a></li>
                <li><a href="kpis.php">KPI管理</a></li>
                <li><a href="action_plans.php">行動方案</a></li>
            </ul>
        </div>
    </nav>
<?php
}

/**
 * 產生HTML頁尾
 */
function renderFooter() {
?>
    <footer style="text-align: center; padding: 30px 0; color: #999; margin-top: 50px; border-top: 1px solid #e0e0e0;">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> | Powered by PHP & MySQL</p>
    </footer>
</body>
</html>
<?php
}
?>